import 'dart:math';
import 'package:flutter_tts/flutter_tts.dart'; // Add this to pubspec.yaml if using TTS

class AiService {
  static final AiService _instance = AiService._internal();
  factory AiService() => _instance;
  AiService._internal();

  bool _isInitialized = false;
  final FlutterTts _tts = FlutterTts(); // For speaking responses

  Future<void> initialize() async {
    await Future.delayed(const Duration(milliseconds: 500));
    _isInitialized = true;
  }

  Future<Emotion> analyzeEmotion(String imagePath) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final random = Random();
    final emotions = EmotionType.values;
    final emotionType = emotions[random.nextInt(emotions.length)];

    return Emotion(
      type: emotionType,
      confidence: 0.5 + random.nextDouble() * 0.5,
    );
  }

  Future<SpeechAnalysis> analyzeSpeech(String speech) async {
    // Simulate analyzing sentiment, stress, and keywords
    await Future.delayed(const Duration(milliseconds: 300));
    final random = Random();

    Sentiment sentiment =
        Sentiment.values[random.nextInt(Sentiment.values.length)];
    double stressLevel = random.nextDouble() * 100;
    List<String> keywords = speech
        .split(' ')
        .where((word) => word.length > 3)
        .take(3)
        .toList();

    return SpeechAnalysis(
      sentiment: sentiment,
      stressLevel: stressLevel,
      keywords: keywords,
    );
  }

  Future<String> generateResponse({
    required String userInput,
    required SpeechAnalysis context,
    required List<EmotionData> emotionHistory,
  }) async {
    await Future.delayed(const Duration(seconds: 1));
    final responses = [
      "I sense you're feeling a bit tense. How about we do a short breathing exercise together?",
      "It's wonderful that you're taking time for yourself today. Let's focus on the present moment.",
      "I notice some stress in your voice. Remember, each breath is an opportunity to release tension.",
      "You're doing great by checking in with yourself. Let's practice some mindful breathing.",
      "It's completely normal to feel this way. Let's focus on our breath and find some calm.",
    ];

    final random = Random();
    return responses[random.nextInt(responses.length)];
  }

  Future<void> speakResponse(String text) async {
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.5);
    await _tts.speak(text);
  }

  Future<UserProfile> getUserProfile() async {
    return UserProfile(
      meditationStreak: 7,
      averageDuration: const Duration(minutes: 12),
      preferredTypes: {MeditationType.breathAwareness, MeditationType.bodyScan},
      stressLevel: 65,
      lastMeditationTime: DateTime.now().subtract(const Duration(hours: 3)),
    );
  }
}

// Models (unchanged)
class Emotion {
  final EmotionType type;
  final double confidence;
  Emotion({required this.type, required this.confidence});
}

enum EmotionType { happy, sad, angry, stressed, tired, neutral }

class EmotionData {
  final Emotion emotion;
  final DateTime timestamp;
  final double confidence;
  EmotionData({
    required this.emotion,
    required this.timestamp,
    required this.confidence,
  });
}

class SpeechAnalysis {
  final Sentiment sentiment;
  final double stressLevel;
  final List<String> keywords;
  SpeechAnalysis({
    required this.sentiment,
    required this.stressLevel,
    required this.keywords,
  });
}

enum Sentiment { positive, negative, neutral }

enum MeditationType {
  breathAwareness,
  bodyScan,
  lovingKindness,
  gratitude,
  stressRelief,
  sleep,
  energyBoost,
}

class MeditationRecommendation {
  final MeditationType type;
  final Duration duration;
  final String reason;
  final double confidence;
  MeditationRecommendation({
    required this.type,
    required this.duration,
    required this.reason,
    required this.confidence,
  });
}

class UserProfile {
  final int meditationStreak;
  final Duration averageDuration;
  final Set<MeditationType> preferredTypes;
  final double stressLevel;
  final DateTime? lastMeditationTime;
  UserProfile({
    required this.meditationStreak,
    required this.averageDuration,
    required this.preferredTypes,
    required this.stressLevel,
    this.lastMeditationTime,
  });
}
