// lib/core/services/ad_service.dart
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'dart:math';
import 'package:mindfulness_garden/features/garden/garden_screen.dart';

class AdService {
  static final AdService _instance = AdService._internal();
  factory AdService() => _instance;
  AdService._internal();

  BannerAd? _bannerAd;
  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  bool _isInitialized = false;

  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    _isInitialized = true;
    _loadAds();
  }

  Future<void> _loadAds() async {
    // Load Banner Ad
    _bannerAd = BannerAd(
      adUnitId: _getBannerAdUnitId(),
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) => print('Banner ad loaded.'),
        onAdFailedToLoad: (ad, error) {
          print('Banner ad failed to load: $error');
          ad.dispose();
        },
      ),
    )..load();

    // Load Interstitial Ad
    await InterstitialAd.load(
      adUnitId: _getInterstitialAdUnitId(),
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              _loadInterstitialAd();
            },
          );
        },
        onAdFailedToLoad: (error) {
          print('Interstitial ad failed to load: $error');
        },
      ),
    );

    // Load Rewarded Ad
    await RewardedAd.load(
      adUnitId: _getRewardedAdUnitId(),
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              _loadRewardedAd();
            },
          );
        },
        onAdFailedToLoad: (error) {
          print('Rewarded ad failed to load: $error');
        },
      ),
    );
  }

  void _loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: _getInterstitialAdUnitId(),
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              _loadInterstitialAd();
            },
          );
        },
        onAdFailedToLoad: (error) {
          _interstitialAd = null;
        },
      ),
    );
  }

  void _loadRewardedAd() {
    RewardedAd.load(
      adUnitId: _getRewardedAdUnitId(),
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              _loadRewardedAd();
            },
          );
        },
        onAdFailedToLoad: (error) {
          _rewardedAd = null;
        },
      ),
    );
  }

  Widget getBannerAdWidget() {
    if (_bannerAd != null) {
      return SizedBox(
        width: _bannerAd!.size.width.toDouble(),
        height: _bannerAd!.size.height.toDouble(),
        child: AdWidget(ad: _bannerAd!),
      );
    }
    return const SizedBox.shrink();
  }

  Future<void> showInterstitialAd() async {
    if (_interstitialAd != null) {
      await _interstitialAd!.show();
    }
  }

  Future<void> showRewardedAd({
    required Function(int) onReward,
    required Function() onFailed,
  }) async {
    if (_rewardedAd != null) {
      _rewardedAd!.show(
        onUserEarnedReward: (ad, reward) {
          onReward(reward.amount.floor());
        },
      );
    } else {
      onFailed();
    }
  }

  String _getBannerAdUnitId() {
    if (kDebugMode) {
      return 'ca-app-pub-3940256099942544/6300978111'; // Test ID
    }
    return 'ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy'; // Production ID
  }

  String _getInterstitialAdUnitId() {
    if (kDebugMode) {
      return 'ca-app-pub-3940256099942544/1033173712'; // Test ID
    }
    return 'ca-app-pub-xxxxxxxxxxxxxxxx/zzzzzzzzzz'; // Production ID
  }

  String _getRewardedAdUnitId() {
    if (kDebugMode) {
      return 'ca-app-pub-3940256099942544/5224354917'; // Test ID
    }
    return 'ca-app-pub-xxxxxxxxxxxxxxxx/wwwwwwwwww'; // Production ID
  }

  void dispose() {
    _bannerAd?.dispose();
    _interstitialAd?.dispose();
    _rewardedAd?.dispose();
  }
}

// Usage in screens
class GardenScreenWithAds extends StatefulWidget {
  const GardenScreenWithAds({super.key});

  @override
  State<GardenScreenWithAds> createState() => _GardenScreenWithAdsState();
}

class _GardenScreenWithAdsState extends State<GardenScreenWithAds> {
  final AdService _adService = AdService();
  int _coins = 100;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Show interstitial ad occasionally
      if (Random().nextInt(5) == 0) {
        _adService.showInterstitialAd();
      }
    });
  }

  void _watchAdForCoins() {
    _adService.showRewardedAd(
      onReward: (coins) {
        setState(() {
          _coins += coins;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('+$coins coins earned!'),
            backgroundColor: Colors.green,
          ),
        );
      },
      onFailed: () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Ad not available. Try again later.'),
            backgroundColor: Colors.red,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Garden'),
        actions: [
          IconButton(
            onPressed: _watchAdForCoins,
            icon: const Icon(Icons.monetization_on),
            tooltip: 'Watch ad for coins',
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: const GardenScreen(), // Your existing garden screen
          ),
          // Banner Ad at bottom
          _adService.getBannerAdWidget(),
        ],
      ),
    );
  }
}
