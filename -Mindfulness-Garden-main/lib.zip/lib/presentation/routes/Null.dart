import 'package:flutter/material.dart';
import 'package:mindfulness_garden/presentation/screens/splash_screen.dart';
import 'package:mindfulness_garden/presentation/screens/main_menu.dart';
import 'package:mindfulness_garden/features/dashboard/dashboard_screen.dart';
import 'package:mindfulness_garden/features/breathing/breathing_menu_screen.dart';
import 'package:mindfulness_garden/features/breathing/exercises/ongo_breathing_screen.dart';
import 'package:mindfulness_garden/features/breathing/exercises/breathing_478_screen.dart';
import 'package:mindfulness_garden/features/breathing/exercises/box_breathing_screen.dart';
import 'package:mindfulness_garden/features/breathing/exercises/breath_awareness_screen.dart';
import 'package:mindfulness_garden/features/garden/garden_screen.dart';
import 'package:mindfulness_garden/features/mood_tracker/mood_tracker_screen.dart';
import 'package:mindfulness_garden/features/progress/progress_screen.dart';
import 'package:mindfulness_garden/features/meditation/guided_meditation_screen.dart';
import 'package:mindfulness_garden/features/meditation/audio_meditation_screen.dart';
import 'package:mindfulness_garden/features/sleep/sleep_tracking_screen.dart';
import 'package:mindfulness_garden/features/sound_therapy/sound_therapy_screen.dart';
import 'package:mindfulness_garden/features/music/meditation_music_screen.dart';
import 'package:mindfulness_garden/features/brainwaves/binaural_beats_screen.dart';
import 'package:mindfulness_garden/features/challenges/daily_challenges_screen.dart';
import 'package:mindfulness_garden/features/achievements/achievements_screen.dart';
import 'package:mindfulness_garden/features/ai_coach/ai_coach_screen.dart';
import 'package:mindfulness_garden/features/biometrics/heart_rate_screen.dart';
import 'package:mindfulness_garden/features/community/friends_screen.dart';
import 'package:mindfulness_garden/features/subscription/subscription_screen.dart';
import 'package:mindfulness_garden/features/settings/settings_screen.dart';

class AppRouterGenerator53 {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case '/main':
        return MaterialPageRoute(builder: (_) => const MainMenuScreen());
      case '/dashboard':
        return MaterialPageRoute(builder: (_) => const DashboardScreen());
      case '/breathing':
        return MaterialPageRoute(builder: (_) => const BreathingMenuScreen());
      case '/breathing/ongo':
        return MaterialPageRoute(builder: (_) => const OngoBreathingScreen());
      case '/breathing/478':
        return MaterialPageRoute(builder: (_) => const Breathing478Screen());
      case '/breathing/box':
        return MaterialPageRoute(builder: (_) => const BoxBreathingScreen());
      case '/breathing/awareness':
        return MaterialPageRoute(builder: (_) => const BreathAwarenessScreen());
      case '/garden':
        return MaterialPageRoute(builder: (_) => const GardenScreen());
      case '/mood':
        return MaterialPageRoute(builder: (_) => const MoodTrackerScreen());
      case '/progress':
        return MaterialPageRoute(builder: (_) => const ProgressScreen());
      case '/meditation/guided':
        return MaterialPageRoute(
          builder: (_) => const GuidedMeditationScreen(),
        );
      case '/meditation/audio':
        return MaterialPageRoute(builder: (_) => const AudioMeditationScreen());
      case '/sleep':
        return MaterialPageRoute(builder: (_) => const SleepTrackingScreen());
      case '/sound':
        return MaterialPageRoute(builder: (_) => const SoundTherapyScreen());
      case '/music':
        return MaterialPageRoute(builder: (_) => const MeditationMusicScreen());
      case '/binaural':
        return MaterialPageRoute(builder: (_) => const BinauralBeatsScreen());
      case '/challenges':
        return MaterialPageRoute(builder: (_) => const DailyChallengesScreen());
      case '/achievements':
        return MaterialPageRoute(builder: (_) => const AchievementsScreen());
      case '/ai-coach':
        return MaterialPageRoute(builder: (_) => const AiCoachScreen());
      case '/heart-rate':
        return MaterialPageRoute(builder: (_) => const HeartRateScreen());
      case '/friends':
        return MaterialPageRoute(builder: (_) => const FriendsScreen());
      case '/subscription':
        return MaterialPageRoute(builder: (_) => const SubscriptionScreen());
      case '/settings':
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(child: Text('No route defined for ${settings.name}')),
          ),
        );
    }
  }
}
