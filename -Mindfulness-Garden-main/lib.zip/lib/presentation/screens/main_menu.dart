// lib/presentation/screens/main_menu.dart - COMPLETE FIXED VERSION WITH SCROLLABLE FOOTER
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:mindfulness_garden/core/widgets/particle_background.dart';
import 'package:mindfulness_garden/presentation/providers/user_provider.dart';

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({super.key});

  @override
  State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _floatingAnimation;
  late Animation<double> _pulseAnimation;
  late Animation<double> _fadeAnimation;

  final List<MenuCategory> _categories = [
    MenuCategory(
      title: 'BREATHING',
      icon: Icons.air,
      color: const Color(0xFF00b4d8),
      gradient: const [Color(0xFF00b4d8), Color(0xFF0077b6)],
      screens: [
        MenuItem(
          title: 'Breathing Exercises',
          icon: Icons.air,
          route: '/breathing',
          description: 'Guided breathing techniques',
          color: Color(0xFF00b4d8),
        ),
        MenuItem(
          title: 'AI Coach',
          icon: Icons.psychology,
          route: '/ai-coach',
          description: 'Personal meditation guidance',
          color: Color(0xFF7209b7),
        ),
        MenuItem(
          title: 'Binaural Beats',
          icon: Icons.waves,
          route: '/binaural-beats',
          description: 'Brainwave entrainment',
          color: Color(0xFF3a86ff),
        ),
      ],
    ),
    MenuCategory(
      title: 'MEDITATION',
      icon: Icons.self_improvement,
      color: const Color(0xFF9d4edd),
      gradient: const [Color(0xFF9d4edd), Color(0xFF560bad)],
      screens: [
        MenuItem(
          title: 'Guided Meditation',
          icon: Icons.headphones,
          route: '/guided-meditation',
          description: 'Step-by-step guidance',
          color: Color(0xFF9d4edd),
        ),
        MenuItem(
          title: 'Meditation Music',
          icon: Icons.library_music,
          route: '/music',
          description: 'Curated meditation tracks',
          color: Color(0xFF4361ee),
        ),
        MenuItem(
          title: 'Sound Therapy',
          icon: Icons.music_note,
          route: '/sound-therapy',
          description: 'Ambient sounds & frequencies',
          color: Color(0xFF4cc9f0),
        ),
      ],
    ),
    MenuCategory(
      title: 'WELLNESS',
      icon: Icons.spa,
      color: const Color(0xFF38b000),
      gradient: const [Color(0xFF38b000), Color(0xFF2d6a4f)],
      screens: [
        MenuItem(
          title: 'My Garden',
          icon: Icons.spa,
          route: '/garden',
          description: 'Interactive mindfulness garden',
          color: Color(0xFF38b000),
        ),
        MenuItem(
          title: 'Mood Tracker',
          icon: Icons.emoji_emotions,
          route: '/mood-tracker',
          description: 'Daily mood logging & insights',
          color: Color(0xFFf72585),
        ),
        MenuItem(
          title: 'Sleep Tracker',
          icon: Icons.bedtime,
          route: '/sleep',
          description: 'Sleep monitoring & analysis',
          color: Color(0xFF3a0ca3),
        ),
      ],
    ),
    MenuCategory(
      title: 'COMMUNITY',
      icon: Icons.people,
      color: const Color(0xFFffb700),
      gradient: const [Color(0xFFffb700), Color(0xFFf48c06)],
      screens: [
        MenuItem(
          title: 'Daily Challenges',
          icon: Icons.emoji_events,
          route: '/challenges',
          description: 'Daily meditation challenges',
          color: Color(0xFFffb700),
        ),
        MenuItem(
          title: 'Friends',
          icon: Icons.people,
          route: '/friends',
          description: 'Connect & meditate together',
          color: Color(0xFFf48c06),
        ),
        MenuItem(
          title: 'Achievements',
          icon: Icons.stars,
          route: '/achievements',
          description: 'Unlock badges & rewards',
          color: Color(0xFFe85d04),
        ),
      ],
    ),
  ];

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      duration: const Duration(seconds: 6),
      vsync: this,
    )..repeat(reverse: true);

    _floatingAnimation = Tween<double>(begin: -15, end: 15).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOutSine,
      ),
    );

    _pulseAnimation = Tween<double>(begin: 0.98, end: 1.02).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _fadeAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    // Load user data
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final userProvider = context.read<UserProvider>();
      userProvider.loadUser();
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userProvider = context.watch<UserProvider>();
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: const Color(0xFF0a0a1a),
      body: Stack(
        children: [
          // Animated gradient background
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF0a0a1a),
                    Color(0xFF1a1a2e),
                    Color(0xFF16213e),
                  ],
                ),
              ),
            ),
          ),

          // Particle background
          Positioned.fill(
            child: ParticleBackground(
              particleCount: 50,
              animationController: _animationController,
            ),
          ),

          // Main content - Everything inside SafeArea and CustomScrollView
          SafeArea(
            child: CustomScrollView(
              slivers: [
                // App header
                SliverToBoxAdapter(
                  child: _buildHeader(userProvider, size),
                ),

                // Daily quote
                SliverToBoxAdapter(
                  child: _buildDailyQuote(),
                ),

                // Categories grid
                SliverPadding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 20,
                  ),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: size.width < 600 ? 0.85 : 1.0,
                    ),
                    delegate: SliverChildBuilderDelegate(
                          (context, index) {
                        final category = _categories[index];
                        return _buildCategoryCard(category, index);
                      },
                      childCount: _categories.length,
                    ),
                  ),
                ),

                // Quick actions section header
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 10,
                    ),
                    child: Text(
                      'Quick Actions',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white.withOpacity(0.9),
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ),

                // Quick actions grid
                SliverPadding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 0.8,
                    ),
                    delegate: SliverChildBuilderDelegate(
                          (context, index) {
                        final actions = [
                          _buildQuickActionItem(
                            icon: Icons.self_improvement,
                            title: 'Start Session',
                            subtitle: 'Begin meditation',
                            color: const Color(0xFF4361ee),
                            onTap: () => context.go('/meditation'),
                          ),
                          _buildQuickActionItem(
                            icon: Icons.spa,
                            title: 'Visit Garden',
                            subtitle: 'Check progress',
                            color: const Color(0xFF38b000),
                            onTap: () => context.go('/garden'),
                          ),
                          _buildQuickActionItem(
                            icon: Icons.insights,
                            title: 'Progress',
                            subtitle: 'View insights',
                            color: const Color(0xFF9d4edd),
                            onTap: () => context.go('/progress'),
                          ),
                        ];
                        return actions[index];
                      },
                      childCount: 3,
                    ),
                  ),
                ),

                // Bottom padding for better scrolling
                const SliverToBoxAdapter(
                  child: SizedBox(height: 60),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(UserProvider userProvider, Size size) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: AnimatedBuilder(
        animation: _floatingAnimation,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, _floatingAnimation.value * 0.5),
            child: child,
          );
        },
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withOpacity(0.05),
                Colors.white.withOpacity(0.02),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(25),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            children: [
              // User avatar with gradient
              Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF667eea).withOpacity(0.4),
                      blurRadius: 15,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Center(
                      child: Icon(
                        Icons.person,
                        color: Colors.white.withOpacity(0.9),
                        size: 32,
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          color: const Color(0xFF38b000),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.star,
                            size: 12,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 16),

              // User info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome back,',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.white.withOpacity(0.7),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Mindful Gardener!',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        height: 1.2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Your garden is growing beautifully',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.white.withOpacity(0.6),
                      ),
                    ),
                  ],
                ),
              ),

              // Streak counter
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.orange.withOpacity(0.3),
                      Colors.red.withOpacity(0.2),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.orange.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.local_fire_department,
                          size: 20,
                          color: Colors.orange,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          '${userProvider.currentStreak}',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Day Streak',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDailyQuote() {
    const quotes = [
      "Mindfulness is the awareness that arises through paying attention, on purpose, in the present moment, non-judgmentally.",
      "The present moment is the only moment where life exists.",
      "Mindfulness isn't difficult, we just need to remember to do it.",
      "In today's rush, we all think too much, seek too much, want too much, and forget about the joy of just being.",
    ];

    final random = Random();
    final quote = quotes[random.nextInt(quotes.length)];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: AnimatedBuilder(
        animation: _fadeAnimation,
        builder: (context, child) {
          return Opacity(
            opacity: _fadeAnimation.value,
            child: child,
          );
        },
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.purple.withOpacity(0.1),
                Colors.blue.withOpacity(0.1),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.05)),
          ),
          child: Row(
            children: [
              Icon(
                Icons.format_quote,
                color: Colors.white.withOpacity(0.3),
                size: 40,
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  quote,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.9),
                    fontStyle: FontStyle.italic,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryCard(MenuCategory category, int index) {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value + (index % 2 == 0 ? 0.01 : 0.0),
          child: Transform.translate(
            offset: Offset(0, index % 2 == 0 ? -5 : 5),
            child: child,
          ),
        );
      },
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
          onTap: () => _showCategoryMenu(category),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: category.gradient,
              ),
              borderRadius: BorderRadius.circular(25),
              boxShadow: [
                BoxShadow(
                  color: category.color.withOpacity(0.4),
                  blurRadius: 20,
                  spreadRadius: 1,
                  offset: const Offset(0, 8),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Stack(
              children: [
                // Decorative circles
                Positioned(
                  top: -20,
                  right: -20,
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.05),
                    ),
                  ),
                ),
                Positioned(
                  bottom: -30,
                  left: -30,
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.03),
                    ),
                  ),
                ),

                // Content
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Icon with background
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          category.icon,
                          color: Colors.white,
                          size: 28,
                        ),
                      ),

                      // Category name
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            category.title,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${category.screens.length} exercises',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.white.withOpacity(0.9),
                            ),
                          ),
                        ],
                      ),

                      // Arrow indicator
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.arrow_forward,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActionItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.03),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 50,
                height: 50,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      color.withOpacity(0.8),
                      color.withOpacity(0.4),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.3),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(
                  icon,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.white.withOpacity(0.6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCategoryMenu(MenuCategory category) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                const Color(0xFF1a1a2e).withOpacity(0.95),
                const Color(0xFF16213e).withOpacity(0.98),
              ],
            ),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 40,
                spreadRadius: 5,
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(25),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        category.color.withOpacity(0.2),
                        category.color.withOpacity(0.1),
                      ],
                    ),
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: category.color.withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          category.icon,
                          color: category.color,
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Text(
                          category.title,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Menu items
                ...category.screens.map((item) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    child: Material(
                      color: Colors.white.withOpacity(0.03),
                      borderRadius: BorderRadius.circular(15),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).pop();
                          _handleMenuItemTap(item);
                        },
                        borderRadius: BorderRadius.circular(15),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Container(
                                width: 45,
                                height: 45,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      item.color.withOpacity(0.3),
                                      item.color.withOpacity(0.1),
                                    ],
                                  ),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  item.icon,
                                  color: item.color,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item.title,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      item.description,
                                      style: TextStyle(
                                        color: Colors.white.withOpacity(0.7),
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: 35,
                                height: 35,
                                decoration: BoxDecoration(
                                  color: item.color.withOpacity(0.2),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.arrow_forward_ios,
                                  color: item.color,
                                  size: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),

                const SizedBox(height: 25),
              ],
            ),
          ),
        );
      },
    );
  }

  void _handleMenuItemTap(MenuItem item) {
    // Check if route exists
    final existingRoutes = [
      '/breathing',
      '/ai-coach',
      '/guided-meditation',
      '/music',
      '/garden',
      '/mood-tracker',
      '/sleep',
      '/challenges',
      '/friends',
      '/achievements',
      '/progress',
      '/meditation'
    ];

    if (existingRoutes.contains(item.route)) {
      context.go(item.route);
    } else {
      // Show coming soon for missing routes
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: Colors.black.withOpacity(0.9),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Text(
            'Coming Soon',
            style: TextStyle(color: Colors.white),
          ),
          content: Text(
            '${item.title} is coming soon!',
            style: const TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text(
                'OK',
                style: TextStyle(color: Colors.blue),
              ),
            ),
          ],
        ),
      );
    }
  }
}

class MenuCategory {
  final String title;
  final IconData icon;
  final Color color;
  final List<Color> gradient;
  final List<MenuItem> screens;

  const MenuCategory({
    required this.title,
    required this.icon,
    required this.color,
    required this.gradient,
    required this.screens,
  });
}

class MenuItem {
  final String title;
  final IconData icon;
  final String route;
  final String description;
  final Color color;

  const MenuItem({
    required this.title,
    required this.icon,
    required this.route,
    required this.description,
    required this.color,
  });
}

