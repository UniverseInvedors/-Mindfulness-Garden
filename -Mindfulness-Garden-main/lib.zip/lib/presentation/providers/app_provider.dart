import 'package:flutter/material.dart';

class AppProvider with ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.system;
  int _streakDays = 24;
  int _totalMinutes = 240;
  String _currentMood = '';

  ThemeMode get themeMode => _themeMode;
  int get streakDays => _streakDays;
  int get totalMinutes => _totalMinutes;
  String get currentMood => _currentMood;

  void toggleTheme(bool isDark) {
    _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    notifyListeners();
  }

  void updateStreak(int days) {
    _streakDays = days;
    notifyListeners();
  }

  void addSessionMinutes(int minutes) {
    _totalMinutes += minutes;
    notifyListeners();
  }

  void setMood(String mood) {
    _currentMood = mood;
    notifyListeners();
  }

  void reset() {
    _streakDays = 0;
    _totalMinutes = 0;
    _currentMood = '';
    notifyListeners();
  }
}
