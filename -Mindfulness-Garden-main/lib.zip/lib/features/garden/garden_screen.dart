import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart'; // Add this import
import 'package:mindfulness_garden/presentation/providers/user_provider.dart';
import 'package:mindfulness_garden/core/services/audio_service.dart';
import 'dart:math';

class GardenScreen extends StatefulWidget {
  const GardenScreen({super.key});

  @override
  State<GardenScreen> createState() => _GardenScreenState();
}

class _GardenScreenState extends State<GardenScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  final AudioService _audioService = AudioService();
  final Random _random = Random();

  List<GardenPlant> _plants = [];
  List<GardenInsect> _insects = [];
  final List<GardenEffect> _effects = [];
  DateTime? _lastInteraction;

  int _coins = 100;
  int _seeds = 5;
  int _water = 3;
  GardenTool _selectedTool = GardenTool.none;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    )..repeat();

    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);

    _initializeGarden();
    _playGardenSound();
  }

  void _initializeGarden() {
    // Initialize plants based on user level
    final userProvider = context.read<UserProvider>();
    final level = userProvider.gardenLevel;

    _plants = List.generate(
      min(level * 2, 12),
      (index) => GardenPlant(
        id: index,
        type: PlantType.values[_random.nextInt(PlantType.values.length)],
        x: _random.nextDouble() * 0.8 + 0.1,
        y: _random.nextDouble() * 0.5 + 0.3,
        size: 0.5 + _random.nextDouble() * 0.5,
        growth: _random.nextDouble() * 0.5,
        waterLevel: 0.7 + _random.nextDouble() * 0.3,
        health: 0.8 + _random.nextDouble() * 0.2,
      ),
    );

    // Initialize insects
    _insects = List.generate(
      min(level, 8),
      (index) => GardenInsect(
        id: index,
        type: InsectType.values[_random.nextInt(InsectType.values.length)],
        x: _random.nextDouble() * 0.9,
        y: _random.nextDouble() * 0.3,
        speed: 0.3 + _random.nextDouble() * 0.7,
        direction: _random.nextDouble() * 2 * pi,
      ),
    );
  }

  void _playGardenSound() async {
    await _audioService.playSound('forest');
  }

  void _plantSeed() {
    if (_seeds > 0) {
      setState(() {
        _seeds--;
        _plants.add(
          GardenPlant(
            id: _plants.length,
            type: PlantType.values[_random.nextInt(PlantType.values.length)],
            x: 0.5,
            y: 0.6,
            size: 0.3,
            growth: 0.0,
            waterLevel: 0.5,
            health: 1.0,
          ),
        );

        // Add planting effect
        _effects.add(
          GardenEffect(type: EffectType.plant, x: 0.5, y: 0.6, lifetime: 1.0),
        );
      });

      _audioService.playSound('bowl');
    }
  }

  void _waterPlant(GardenPlant plant) {
    if (_water > 0) {
      setState(() {
        _water--;
        plant.waterLevel = min(1.0, plant.waterLevel + 0.3);
        plant.growth = min(1.0, plant.growth + 0.1);

        // Add water effect
        _effects.add(
          GardenEffect(
            type: EffectType.water,
            x: plant.x,
            y: plant.y,
            lifetime: 1.5,
          ),
        );
      });

      _audioService.playSound('rain');
    }
  }

  void _harvestPlant(GardenPlant plant) {
    if (plant.growth >= 1.0) {
      setState(() {
        _plants.remove(plant);
        _coins += 50;
        _seeds += 2;

        // Add harvest effect
        _effects.add(
          GardenEffect(
            type: EffectType.coin,
            x: plant.x,
            y: plant.y,
            lifetime: 2.0,
          ),
        );
      });

      _audioService.playSound('piano');
    }
  }

  void _updateGarden(double dt) {
    // Update plants
    for (final plant in _plants) {
      plant.growth = min(1.0, plant.growth + dt * 0.01);
      plant.waterLevel = max(0.0, plant.waterLevel - dt * 0.005);
      plant.health = max(0.0, plant.health - dt * 0.001);
    }

    // Update insects
    for (final insect in _insects) {
      insect.x += cos(insect.direction) * insect.speed * dt;
      insect.y += sin(insect.direction) * insect.speed * dt;

      // Bounce off edges
      if (insect.x < 0.1 || insect.x > 0.9) {
        insect.direction = pi - insect.direction;
      }
      if (insect.y < 0.1 || insect.y > 0.7) {
        insect.direction = -insect.direction;
      }
    }

    // Update effects
    _effects.removeWhere((effect) {
      effect.lifetime -= dt;
      return effect.lifetime <= 0;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _audioService.stopSound();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userProvider = context.watch<UserProvider>();

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(), // Fixed: using GoRouter pop
        ),
        title: const Text(
          'My Garden',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w800,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              // Show garden info
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Garden Info'),
                  content: const Text(
                    'Water your plants to help them grow! '
                    'Harvest them when they\'re fully grown to earn coins.',
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(), // Fixed
                      child: const Text('OK'),
                    ),
                  ],
                ),
              );
            },
            icon: const Icon(Icons.info, color: Colors.white),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF87CEEB), Color(0xFF98FB98), Color(0xFF32CD32)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Resources Bar
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildResourceItem(
                      Icons.emoji_events,
                      'Level ${userProvider.gardenLevel}',
                    ),
                    _buildResourceItem(Icons.attach_money, '$_coins'),
                    _buildResourceItem(Icons.grass, '$_seeds'),
                    _buildResourceItem(Icons.water_drop, '$_water'),
                  ],
                ),
              ),

              // Garden View
              Expanded(
                child: Stack(
                  children: [
                    // Sky
                    Positioned.fill(
                      child: AnimatedBuilder(
                        animation: _controller,
                        builder: (context, child) {
                          return Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.blue.withOpacity(
                                    0.8 + sin(_animation.value * pi) * 0.1,
                                  ),
                                  Colors.lightBlue.withOpacity(0.9),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),

                    // Sun
                    Positioned(
                      top: 30,
                      right: 30,
                      child: AnimatedBuilder(
                        animation: _controller,
                        builder: (context, child) {
                          return Transform.rotate(
                            angle: _animation.value * 2 * pi,
                            child: const Icon(
                              Icons.wb_sunny,
                              size: 60,
                              color: Colors.orange,
                            ),
                          );
                        },
                      ),
                    ),

                    // Animated Clouds
                    ..._buildClouds(),

                    // Ground
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 150,
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Color(0xFF8B4513), Color(0xFF654321)],
                          ),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(40),
                            topRight: Radius.circular(40),
                          ),
                        ),
                      ),
                    ),

                    // Interactive Plants
                    ..._plants.map((plant) => _buildPlant(plant)),

                    // Insects
                    ..._insects.map((insect) => _buildInsect(insect)),

                    // Effects
                    ..._effects.map((effect) => _buildEffect(effect)),

                    // Water Feature
                    Positioned(
                      left: 50,
                      bottom: 100,
                      child: AnimatedBuilder(
                        animation: _controller,
                        builder: (context, child) {
                          return Transform.translate(
                            offset: Offset(
                              0,
                              sin(_animation.value * 2 * pi) * 5,
                            ),
                            child: Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                color: Colors.blue.withOpacity(0.6),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.blue.withOpacity(0.4),
                                    blurRadius: 20,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.waves,
                                color: Colors.white,
                                size: 40,
                              ),
                            ),
                          );
                        },
                      ),
                    ),

                    // Meditation Spot
                    Positioned(
                      bottom: 80,
                      left: MediaQuery.of(context).size.width / 2 - 30,
                      child: GestureDetector(
                        onTap: () {
                          // Navigate to meditation using GoRouter
                          Navigator.of(context).pushNamed('/meditation');
                        },
                        child: Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            color: const Color(0xFF6C63FF).withOpacity(0.9),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF6C63FF).withOpacity(0.3),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.self_improvement,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Tools Bar
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildToolButton(Icons.grass, 'Plant', GardenTool.plant),
                    _buildToolButton(
                      Icons.water_drop,
                      'Water',
                      GardenTool.water,
                    ),
                    _buildToolButton(
                      Icons.agriculture,
                      'Harvest',
                      GardenTool.harvest,
                    ),
                    _buildToolButton(
                      Icons.auto_awesome,
                      'Effects',
                      GardenTool.effects,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResourceItem(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.3),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.white),
          const SizedBox(width: 5),
          Text(
            text,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildClouds() {
    return [
      Positioned(
        top: 50,
        left: 20,
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(_animation.value * 100, 0),
              child: const Icon(Icons.cloud, size: 40, color: Colors.white),
            );
          },
        ),
      ),
      Positioned(
        top: 80,
        right: 50,
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(
                -_animation.value * 80,
                sin(_animation.value * pi) * 10,
              ),
              child: const Icon(Icons.cloud, size: 60, color: Colors.white),
            );
          },
        ),
      ),
    ];
  }

  Widget _buildPlant(GardenPlant plant) {
    return Positioned(
      left: plant.x * MediaQuery.of(context).size.width,
      bottom: plant.y * MediaQuery.of(context).size.height,
      child: GestureDetector(
        onTap: () {
          switch (_selectedTool) {
            case GardenTool.water:
              _waterPlant(plant);
              break;
            case GardenTool.harvest:
              _harvestPlant(plant);
              break;
            default:
              // Show plant info
              _showPlantInfo(plant);
              break;
          }
        },
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, sin(_controller.value * 2 * pi + plant.id) * 5),
              child: Transform.scale(
                scale: 0.5 + plant.size * plant.growth,
                child: Stack(
                  children: [
                    // Plant
                    Icon(
                      _getPlantIcon(plant.type),
                      size: 60,
                      color: _getPlantColor(
                        plant.type,
                      ).withOpacity(plant.health),
                    ),

                    // Growth indicator
                    if (plant.growth < 1.0)
                      Positioned(
                        bottom: -10,
                        left: 0,
                        right: 0,
                        child: Container(
                          height: 4,
                          width: 40,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(2),
                          ),
                          child: FractionallySizedBox(
                            alignment: Alignment.centerLeft,
                            widthFactor: plant.growth,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                          ),
                        ),
                      ),

                    // Water indicator
                    Positioned(
                      top: -10,
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 4,
                        width: 40,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                        child: FractionallySizedBox(
                          alignment: Alignment.centerLeft,
                          widthFactor: plant.waterLevel,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _showPlantInfo(GardenPlant plant) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${_getPlantName(plant.type)} Info'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Growth: ${(plant.growth * 100).toInt()}%'),
            Text('Water: ${(plant.waterLevel * 100).toInt()}%'),
            Text('Health: ${(plant.health * 100).toInt()}%'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  String _getPlantName(PlantType type) {
    switch (type) {
      case PlantType.flower:
        return 'Flower';
      case PlantType.tree:
        return 'Tree';
      case PlantType.bush:
        return 'Bush';
      case PlantType.herb:
        return 'Herb';
      case PlantType.mushroom:
        return 'Mushroom';
    }
  }

  Widget _buildInsect(GardenInsect insect) {
    return Positioned(
      left: insect.x * MediaQuery.of(context).size.width,
      bottom: insect.y * MediaQuery.of(context).size.height,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          final offsetX =
              cos(insect.direction + _controller.value * insect.speed) * 10;
          final offsetY =
              sin(insect.direction + _controller.value * insect.speed) * 10;

          return Transform.translate(
            offset: Offset(offsetX, offsetY),
            child: Transform.rotate(
              angle: insect.direction,
              child: Icon(
                _getInsectIcon(insect.type),
                size: 24,
                color: _getInsectColor(insect.type),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEffect(GardenEffect effect) {
    return Positioned(
      left: effect.x * MediaQuery.of(context).size.width,
      bottom: effect.y * MediaQuery.of(context).size.height,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          final scale = 1.0 - effect.lifetime;
          final opacity = effect.lifetime;

          return Transform.scale(
            scale: scale,
            child: Opacity(
              opacity: opacity,
              child: Icon(
                _getEffectIcon(effect.type),
                size: 40,
                color: _getEffectColor(effect.type),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildToolButton(IconData icon, String label, GardenTool tool) {
    final isSelected = _selectedTool == tool;

    return Column(
      children: [
        GestureDetector(
          onTap: () {
            setState(() {
              if (tool == GardenTool.plant) {
                _plantSeed();
              } else {
                _selectedTool = isSelected ? GardenTool.none : tool;
              }
            });
          },
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: isSelected
                  ? Colors.white.withOpacity(0.3)
                  : Colors.white.withOpacity(0.2),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.4),
                width: 2,
              ),
            ),
            child: Icon(icon, color: Colors.white, size: 30),
          ),
        ),
        const SizedBox(height: 5),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.white.withOpacity(isSelected ? 1.0 : 0.8),
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ],
    );
  }

  // Helper methods
  IconData _getPlantIcon(PlantType type) {
    switch (type) {
      case PlantType.flower:
        return Icons.local_florist;
      case PlantType.tree:
        return Icons.park;
      case PlantType.bush:
        return Icons.forest;
      case PlantType.herb:
        return Icons.grass;
      case PlantType.mushroom:
        return Icons.eco;
    }
  }

  Color _getPlantColor(PlantType type) {
    switch (type) {
      case PlantType.flower:
        return Colors.pink;
      case PlantType.tree:
        return Colors.green;
      case PlantType.bush:
        return Colors.green.shade700;
      case PlantType.herb:
        return Colors.lightGreen;
      case PlantType.mushroom:
        return Colors.brown;
    }
  }

  IconData _getInsectIcon(InsectType type) {
    switch (type) {
      case InsectType.butterfly:
        return Icons.bug_report;
      case InsectType.bee:
        return Icons.bed_rounded;
      case InsectType.ladybug:
        return Icons.circle;
      case InsectType.dragonfly:
        return Icons.flight;
    }
  }

  Color _getInsectColor(InsectType type) {
    switch (type) {
      case InsectType.butterfly:
        return Colors.purple;
      case InsectType.bee:
        return Colors.yellow.shade700;
      case InsectType.ladybug:
        return Colors.red;
      case InsectType.dragonfly:
        return Colors.blue;
    }
  }

  IconData _getEffectIcon(EffectType type) {
    switch (type) {
      case EffectType.plant:
        return Icons.grass;
      case EffectType.water:
        return Icons.water_drop;
      case EffectType.coin:
        return Icons.monetization_on;
    }
  }

  Color _getEffectColor(EffectType type) {
    switch (type) {
      case EffectType.plant:
        return Colors.green;
      case EffectType.water:
        return Colors.blue;
      case EffectType.coin:
        return Colors.yellow;
    }
  }
}

// Models
enum PlantType { flower, tree, bush, herb, mushroom }

enum InsectType { butterfly, bee, ladybug, dragonfly }

enum EffectType { plant, water, coin }

enum GardenTool { none, plant, water, harvest, effects }

class GardenPlant {
  int id;
  PlantType type;
  double x;
  double y;
  double size;
  double growth;
  double waterLevel;
  double health;

  GardenPlant({
    required this.id,
    required this.type,
    required this.x,
    required this.y,
    required this.size,
    required this.growth,
    required this.waterLevel,
    required this.health,
  });
}

class GardenInsect {
  int id;
  InsectType type;
  double x;
  double y;
  double speed;
  double direction;

  GardenInsect({
    required this.id,
    required this.type,
    required this.x,
    required this.y,
    required this.speed,
    required this.direction,
  });
}

class GardenEffect {
  EffectType type;
  double x;
  double y;
  double lifetime;

  GardenEffect({
    required this.type,
    required this.x,
    required this.y,
    required this.lifetime,
  });
}
