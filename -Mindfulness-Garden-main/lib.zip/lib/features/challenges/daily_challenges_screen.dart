import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mindfulness_garden/presentation/providers/challenge_provider.dart';
import 'package:mindfulness_garden/data/models/challenge_model.dart';

class DailyChallengesScreen extends StatefulWidget {
  const DailyChallengesScreen({super.key});

  @override
  State<DailyChallengesScreen> createState() => _DailyChallengesScreenState();
}

class _DailyChallengesScreenState extends State<DailyChallengesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ChallengeProvider>().loadChallenges();
    });
  }

  @override
  Widget build(BuildContext context) {
    final challengeProvider = context.watch<ChallengeProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Challenges'),
        actions: [
          IconButton(
            onPressed: _showRewards,
            icon: const Icon(Icons.emoji_events),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF667eea), Color(0xFF764ba2)],
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Streak Info
            _buildStreakCard(challengeProvider),
            const SizedBox(height: 20),

            // Daily Challenge
            _buildDailyChallenge(challengeProvider),
            const SizedBox(height: 20),

            // Weekly Challenges
            _buildWeeklyChallenges(challengeProvider),
            const SizedBox(height: 20),

            // Achievement Progress
            _buildAchievementProgress(),
          ],
        ),
      ),
    );
  }

  Widget _buildStreakCard(ChallengeProvider provider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.1 * 255),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Text(
            '🔥 ${provider.challenges} DAY STREAK',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: provider.points.toDouble(),
            backgroundColor: Colors.white.withValues(alpha: 0.2 * 255),
            color: Colors.orange,
          ),
          const SizedBox(height: 10),
          Text(
            'Complete 7 days for special reward!',
            style: TextStyle(
              fontSize: 14,
              color: Colors.white.withValues(alpha: 0.8 * 255),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDailyChallenge(ChallengeProvider provider) {
    final challenge = provider.todayChallenge;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF00b4d8).withValues(alpha: 0.8 * 255),
            const Color(0xFF0077b6).withValues(alpha: 0.8 * 255),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00b4d8).withValues(alpha: 0.3 * 255),
            blurRadius: 20,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.today, color: Colors.white),
              const SizedBox(width: 10),
              const Text(
                "TODAY'S CHALLENGE",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2 * 255),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '+${challenge?.reward ?? 0} Coins',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          Text(
            challenge?.title ?? 'No Challenge Available',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            challenge?.description ?? 'Check back tomorrow for new challenges',
            style: TextStyle(
              fontSize: 14,
              color: Colors.white.withValues(alpha: 0.9 * 255),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: challenge?.isCompleted == true
                      ? null
                      : () {
                          if (challenge != null) {
                            provider.completeChallenge(challenge.id);
                            _showChallengeComplete(challenge);
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: challenge?.isCompleted == true
                        ? Colors.green
                        : Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  child: Text(
                    challenge?.isCompleted == true
                        ? 'COMPLETED ✓'
                        : 'START CHALLENGE',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: challenge?.isCompleted == true
                          ? Colors.white
                          : const Color(0xFF0077b6),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildWeeklyChallenges(ChallengeProvider provider) {
    final weeklyChallenges = provider.challenges;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'WEEKLY CHALLENGES',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 15),
        ...weeklyChallenges.map((challenge) {
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05 * 255),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1 * 255),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  challenge.isCompleted
                      ? Icons.check_circle
                      : Icons.radio_button_unchecked,
                  color: challenge.isCompleted
                      ? Colors.green
                      : Colors.white.withValues(alpha: 0.5 * 255),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        challenge.title,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: challenge.isCompleted
                              ? Colors.white
                              : Colors.white.withValues(alpha: 0.9 * 255),
                        ),
                      ),
                      Text(
                        challenge.description,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white.withValues(alpha: 0.7 * 255),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.1 * 255),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '+${challenge.reward}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ],
    );
  }

  Widget _buildAchievementProgress() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.1 * 255),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'ACHIEVEMENT PROGRESS',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 15),
          _buildProgressItem('Meditation Master', 0.75),
          _buildProgressItem('Breathing Expert', 0.5),
          _buildProgressItem('Mindfulness Guru', 0.25),
        ],
      ),
    );
  }

  Widget _buildProgressItem(String title, double progress) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(color: Colors.white),
              ),
              Text(
                '${(progress * 100).toInt()}%',
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.8 * 255),
                ),
              ),
            ],
          ),
          const SizedBox(height: 5),
          LinearProgressIndicator(
            value: progress,
            backgroundColor: Colors.white.withValues(alpha: 0.2 * 255),
            color: Colors.green,
          ),
        ],
      ),
    );
  }

  void _showRewards() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        title: const Text(
          'Your Rewards',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildRewardItem('7 Day Streak', 'Special Plant Unlocked', 100),
            _buildRewardItem('14 Day Streak', 'New Garden Theme', 250),
            _buildRewardItem('30 Day Streak', 'All Features Unlocked', 500),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _buildRewardItem(String title, String description, int coins) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05 * 255),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        children: [
          const Icon(Icons.emoji_events, color: Colors.yellow),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  description,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.7 * 255),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.yellow.withValues(alpha: 0.2 * 255),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                const Icon(Icons.attach_money, size: 14, color: Colors.yellow),
                const SizedBox(width: 5),
                Text(
                  coins.toString(),
                  style: const TextStyle(
                    color: Colors.yellow,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showChallengeComplete(Challenge challenge) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        title: const Text(
          'Challenge Complete! 🎉',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.emoji_events, size: 60, color: Colors.yellow),
            const SizedBox(height: 20),
            Text(
              '+${challenge.reward} Coins Earned',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: Colors.yellow,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              challenge.title,
              style: const TextStyle(color: Colors.white),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child:
                const Text('Awesome!', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

