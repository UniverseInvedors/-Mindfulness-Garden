import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mindfulness_garden/presentation/providers/app_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _darkModeEnabled = false;
  bool _autoPlaySounds = true;
  bool _vibrationEnabled = true;
  String _selectedTheme = 'System';
  String _selectedLanguage = 'English';
  double _volumeLevel = 0.7;

  final List<String> _languages = [
    'English',
    'Spanish',
    'French',
    'German',
    'Hindi',
    'Chinese',
  ];

  final List<String> _themes = ['System', 'Light', 'Dark'];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.colorScheme.primary;
    final onSurfaceColor = theme.colorScheme.onSurface;

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile Section
            _buildProfileSection(primaryColor, onSurfaceColor),
            const SizedBox(height: 32),

            // General Settings
            _buildSectionTitle('General', onSurfaceColor),
            _buildSettingCard(
              title: 'Theme',
              subtitle: 'App appearance',
              trailing: _buildThemeDropdown(),
            ),
            _buildSettingSwitch(
              title: 'Dark Mode',
              subtitle: 'Enable dark theme',
              value: _darkModeEnabled,
              onChanged: (value) {
                setState(() {
                  _darkModeEnabled = value;
                });
                context.read<AppProvider>().toggleTheme(value);
              },
            ),
            _buildSettingDropdown(
              title: 'Language',
              value: _selectedLanguage,
              items: _languages,
              onChanged: (value) {
                setState(() {
                  _selectedLanguage = value!;
                });
              },
            ),

            const SizedBox(height: 24),

            // Notification Settings
            _buildSectionTitle('Notifications', onSurfaceColor),
            _buildSettingSwitch(
              title: 'Enable Notifications',
              subtitle: 'Daily reminders and updates',
              value: _notificationsEnabled,
              onChanged: (value) {
                setState(() {
                  _notificationsEnabled = value;
                });
              },
            ),
            _buildSettingTime(
              title: 'Daily Reminder',
              subtitle: 'Time for daily meditation reminder',
              time: const TimeOfDay(hour: 9, minute: 0),
              primaryColor: primaryColor,
            ),

            const SizedBox(height: 24),

            // Audio Settings
            _buildSectionTitle('Audio', onSurfaceColor),
            _buildSettingSwitch(
              title: 'Auto-play Sounds',
              subtitle: 'Play ambient sounds automatically',
              value: _autoPlaySounds,
              onChanged: (value) {
                setState(() {
                  _autoPlaySounds = value;
                });
              },
            ),
            _buildSettingSwitch(
              title: 'Vibration',
              subtitle: 'Haptic feedback during sessions',
              value: _vibrationEnabled,
              onChanged: (value) {
                setState(() {
                  _vibrationEnabled = value;
                });
              },
            ),
            _buildSettingSlider(
              title: 'Volume Level',
              value: _volumeLevel,
              onChanged: (value) {
                setState(() {
                  _volumeLevel = value;
                });
              },
              primaryColor: primaryColor,
            ),

            const SizedBox(height: 24),

            // Data Section
            _buildSectionTitle('Data', onSurfaceColor),
            _buildSettingButton(
              title: 'Export Data',
              subtitle: 'Export your meditation data',
              onTap: _exportData,
            ),
            _buildSettingButton(
              title: 'Clear Data',
              subtitle: 'Reset all app data',
              onTap: _showClearDataDialog,
            ),

            const SizedBox(height: 24),

            // About Section
            _buildSectionTitle('About', onSurfaceColor),
            _buildSettingButton(
              title: 'Privacy Policy',
              subtitle: 'Read our privacy policy',
              onTap: _openPrivacyPolicy,
            ),
            _buildSettingButton(
              title: 'Terms of Service',
              subtitle: 'Read our terms and conditions',
              onTap: _openTerms,
            ),
            _buildSettingButton(
              title: 'Rate App',
              subtitle: 'Share your feedback',
              onTap: _rateApp,
            ),
            _buildSettingButton(
              title: 'App Version',
              subtitle: '1.0.0',
              onTap: () {},
            ),

            const SizedBox(height: 40),

            // Sign Out Button
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _signOut,
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  side: BorderSide(color: Colors.red.withAlpha(76)),
                ),
                child: Text(
                  'Sign Out',
                  style: TextStyle(
                    color: Colors.red.withAlpha(200),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileSection(Color primaryColor, Color textColor) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(12),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: primaryColor,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.person, color: Colors.white, size: 30),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'John Doe',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  'john.doe@example.com',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: textColor.withAlpha(150),
                  ),
                ),
              ],
            ),
          ),
          IconButton(onPressed: () {}, icon: const Icon(Icons.edit)),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, Color textColor) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        title,
        style: Theme.of(
          context,
        ).textTheme.titleMedium?.copyWith(color: textColor.withAlpha(150)),
      ),
    );
  }

  Widget _buildSettingCard({
    required String title,
    required String subtitle,
    required Widget trailing,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(
                    context,
                  ).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(
                      context,
                    ).colorScheme.onSurface.withAlpha(150),
                  ),
                ),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }

  Widget _buildThemeDropdown() {
    return DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        value: _selectedTheme,
        items: _themes.map((theme) {
          return DropdownMenuItem(value: theme, child: Text(theme));
        }).toList(),
        onChanged: (value) {
          setState(() {
            _selectedTheme = value!;
          });
        },
      ),
    );
  }

  Widget _buildSettingSwitch({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return _buildSettingCard(
      title: title,
      subtitle: subtitle,
      trailing: Switch(
        value: value,
        onChanged: onChanged,
        activeColor: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  Widget _buildSettingDropdown({
    required String title,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return _buildSettingCard(
      title: title,
      subtitle: '',
      trailing: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          items: items.map((item) {
            return DropdownMenuItem(value: item, child: Text(item));
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildSettingTime({
    required String title,
    required String subtitle,
    required TimeOfDay time,
    required Color primaryColor,
  }) {
    return _buildSettingCard(
      title: title,
      subtitle: subtitle,
      trailing: TextButton(
        onPressed: () async {
          final newTime = await showTimePicker(
            context: context,
            initialTime: time,
          );
          if (newTime != null) {
            // Handle time selection
          }
        },
        child: Text(
          '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}',
          style: TextStyle(color: primaryColor),
        ),
      ),
    );
  }

  Widget _buildSettingSlider({
    required String title,
    required double value,
    required ValueChanged<double> onChanged,
    required Color primaryColor,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(
              context,
            ).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          Slider(
            value: value,
            onChanged: onChanged,
            min: 0,
            max: 1,
            divisions: 10,
            label: '${(value * 100).toInt()}%',
            activeColor: primaryColor,
            inactiveColor: Colors.grey.withAlpha(76),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingButton({
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListTile(
        title: Text(
          title,
          style: Theme.of(
            context,
          ).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          subtitle,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withAlpha(150),
          ),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  Future<void> _exportData() async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Export feature coming soon!')),
    );
  }

  Future<void> _showClearDataDialog() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear All Data?'),
        content: const Text(
          'This will delete all your meditation sessions, mood entries, and settings. This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _clearData();
            },
            child: const Text('Clear', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<void> _clearData() async {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Data cleared successfully')));
  }

  void _openPrivacyPolicy() {
    // TODO: Open privacy policy
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Privacy policy will open soon')),
    );
  }

  void _openTerms() {
    // TODO: Open terms of service
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Terms of service will open soon')),
    );
  }

  void _rateApp() {
    // TODO: Open app store rating
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Rating feature coming soon')));
  }

  void _signOut() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sign Out?'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              // TODO: Implement sign out logic
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Signed out successfully')),
              );
            },
            child: const Text('Sign Out', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

