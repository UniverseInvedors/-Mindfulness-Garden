import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:mindfulness_garden/core/services/audio_service.dart';
import 'package:mindfulness_garden/core/services/tts_service.dart';
import 'package:mindfulness_garden/presentation/providers/session_provider.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'dart:async';

@RoutePage()
class BreathAwarenessScreen extends StatefulWidget {
  const BreathAwarenessScreen({super.key});

  @override
  State<BreathAwarenessScreen> createState() => _BreathAwarenessScreenState();
}

class _BreathAwarenessScreenState extends State<BreathAwarenessScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _breathAnimation;
  late Animation<double> _glowAnimation;

  final AudioService _audioService = AudioService();
  final TtsService _ttsService = TtsService();

  Timer? _meditationTimer;
  Timer? _instructionTimer;
  int _remainingSeconds = 600; // 10 minutes
  bool _isPlaying = false;
  bool _isPaused = false;
  List<String> _instructions = [];
  int _currentInstruction = 0;
  MeditationPhase _phase = MeditationPhase.preparation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    );

    _breathAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 0.8,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _setupInstructions();
    _playAmbientSound();
  }

  void _setupInstructions() {
    _instructions = [
      "Find a comfortable position...",
      "Close your eyes gently...",
      "Bring your attention to your breath...",
      "Notice the natural rhythm of your breathing...",
      "Don't try to change it, just observe...",
      "Feel the air entering your nostrils...",
      "Notice the temperature of the breath...",
      "Feel your chest and abdomen rise and fall...",
      "If your mind wanders, gently bring it back...",
      "Continue observing your breath...",
      "Notice the space between breaths...",
      "Stay with the sensation of breathing...",
      "Observe without judgment...",
      "Allow thoughts to come and go...",
      "Return to the breath...",
      "Feel the present moment...",
      "Gently bring awareness back to your body...",
      "When you're ready, open your eyes...",
    ];
  }

  void _playAmbientSound() async {
    await _audioService.playSound('piano');
  }

  void _startMeditation() {
    setState(() {
      _isPlaying = true;
      _phase = MeditationPhase.preparation;
    });

    // Start breathing animation
    _controller.repeat(reverse: true);

    // Start meditation timer
    _meditationTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isPaused) {
        setState(() {
          if (_remainingSeconds > 0) {
            _remainingSeconds--;

            // Progress through phases
            if (_remainingSeconds == 540) {
              // After 1 minute
              _phase = MeditationPhase.focusing;
              _speakInstruction("Bring your attention to your breath...");
            } else if (_remainingSeconds == 300) {
              // After 5 minutes
              _phase = MeditationPhase.deepening;
              _speakInstruction("Notice the subtle sensations of breathing...");
            } else if (_remainingSeconds == 60) {
              // Last minute
              _phase = MeditationPhase.closing;
              _speakInstruction("Begin to bring your awareness back...");
            } else if (_remainingSeconds == 0) {
              _completeMeditation();
              timer.cancel();
            }

            // Give random gentle reminders
            if (_remainingSeconds % 120 == 0 && _remainingSeconds > 60) {
              _speakInstruction(
                _instructions[_currentInstruction % _instructions.length],
              );
              _currentInstruction++;
            }
          }
        });
      }
    });

    // Give initial instruction
    _speakInstruction("Let's begin our breath awareness practice...");
  }

  void _pauseMeditation() {
    setState(() {
      _isPaused = true;
      _controller.stop();
    });

    _ttsService.speak("Meditation paused");
  }

  void _resumeMeditation() {
    setState(() {
      _isPaused = false;
      _controller.repeat(reverse: true);
    });

    _ttsService.speak("Resuming meditation");
  }

  void _completeMeditation() {
    setState(() {
      _isPlaying = false;
      _phase = MeditationPhase.complete;
      _controller.stop();
    });

    // Save session
    final sessionProvider = context.read<SessionProvider>();
    sessionProvider.saveSession(
      durationMinutes: 10,
      meditationType: 'Breath Awareness',
    );

    // Speak completion message
    _ttsService.speak("Meditation complete. Well done.");

    // Play completion sound
    _audioService.playSound('bowl');
  }

  Future<void> _speakInstruction(String text) async {
    await _ttsService.speak(text);
  }

  String _getPhaseTitle() {
    switch (_phase) {
      case MeditationPhase.preparation:
        return 'Preparation';
      case MeditationPhase.focusing:
        return 'Focusing';
      case MeditationPhase.deepening:
        return 'Deepening';
      case MeditationPhase.closing:
        return 'Closing';
      case MeditationPhase.complete:
        return 'Complete';
    }
  }

  Color _getPhaseColor() {
    switch (_phase) {
      case MeditationPhase.preparation:
        return Colors.blue;
      case MeditationPhase.focusing:
        return Colors.green;
      case MeditationPhase.deepening:
        return Colors.purple;
      case MeditationPhase.closing:
        return Colors.orange;
      case MeditationPhase.complete:
        return Colors.green;
    }
  }

  String _getTimerText() {
    final minutes = _remainingSeconds ~/ 60;
    final seconds = _remainingSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _controller.dispose();
    _meditationTimer?.cancel();
    _instructionTimer?.cancel();
    _audioService.stopSound();
    _ttsService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1a1a2e),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // Header
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.go('/breathing'),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'Breath Awareness',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const Spacer(),
                  if (_isPlaying)
                    IconButton(
                      onPressed:
                          _isPaused ? _resumeMeditation : _pauseMeditation,
                      icon: Icon(
                        _isPaused ? Icons.play_arrow : Icons.pause,
                        color: Colors.white,
                        size: 30,
                      ),
                    ),
                ],
              ),

              const SizedBox(height: 30),

              // Timer and Phase
              Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: _getPhaseColor().withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      _getPhaseTitle(),
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: _getPhaseColor(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    _getTimerText(),
                    style: const TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.w300,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 40),

              // Breathing Visualization
              Expanded(
                child: Center(
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          // Outer glow
                          Container(
                            width: 300,
                            height: 300,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  _getPhaseColor().withOpacity(
                                    _glowAnimation.value * 0.3,
                                  ),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),

                          // Breathing circle
                          Container(
                            width: 100 + _breathAnimation.value * 100,
                            height: 100 + _breathAnimation.value * 100,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  _getPhaseColor(),
                                  _getPhaseColor().withOpacity(0.7),
                                ],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _getPhaseColor().withOpacity(0.5),
                                  blurRadius: 30,
                                  spreadRadius: 5,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Icon(
                                Icons.air,
                                size: 40,
                                color: Colors.white,
                              ),
                            ),
                          ),

                          // Instruction text
                          Positioned(
                            bottom: 50,
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width * 0.8,
                              child: Text(
                                _isPlaying
                                    ? "Focus on your natural breathing pattern"
                                    : "Start your breath awareness journey",
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),

              const SizedBox(height: 40),

              // Controls
              if (!_isPlaying && _phase != MeditationPhase.complete)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _startMeditation,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: const Text(
                      'BEGIN MEDITATION',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                )
              else if (_phase == MeditationPhase.complete)
                Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          // Restart meditation
                          setState(() {
                            _remainingSeconds = 600;
                            _phase = MeditationPhase.preparation;
                          });
                          _startMeditation();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: const Text(
                          'MEDITATE AGAIN',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: () => context.router.maybePop(),
                      child: const Text(
                        'BACK TO MENU',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

enum MeditationPhase { preparation, focusing, deepening, closing, complete }
