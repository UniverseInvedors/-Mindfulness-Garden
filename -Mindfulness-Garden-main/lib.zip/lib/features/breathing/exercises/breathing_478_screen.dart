import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:mindfulness_garden/core/services/audio_service.dart';
import 'package:mindfulness_garden/core/services/tts_service.dart';
import 'package:mindfulness_garden/presentation/providers/session_provider.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'dart:async';

@RoutePage()
class Breathing478Screen extends StatefulWidget {
  const Breathing478Screen({super.key});

  @override
  State<Breathing478Screen> createState() => _Breathing478ScreenState();
}

class _Breathing478ScreenState extends State<Breathing478Screen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _colorAnimation;

  final AudioService _audioService = AudioService();
  final TtsService _ttsService = TtsService();

  Timer? _cycleTimer;
  int _currentSecond = 0;
  int _totalCycles = 0;
  BreathingPhase _phase = BreathingPhase.inhale;
  bool _isRunning = true;
  bool _showGuide = true;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    );

    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 0.8, end: 1.2), weight: 1),
      TweenSequenceItem(tween: Tween<double>(begin: 1.2, end: 1.2), weight: 1),
      TweenSequenceItem(tween: Tween<double>(begin: 1.2, end: 0.8), weight: 1),
    ]).animate(_controller);

    _colorAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);

    _playAmbientSound();
    _startBreathingCycle();
  }

  void _playAmbientSound() async {
    await _audioService.playSound('piano');
  }

  void _startBreathingCycle() {
    _cycleTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isRunning) return;

      setState(() {
        _currentSecond++;

        // 4-7-8 breathing pattern
        if (_currentSecond <= 4) {
          _phase = BreathingPhase.inhale;
          if (_currentSecond == 1) {
            _ttsService.speak("Inhale for 4 seconds");
            _controller.forward();
          }
        } else if (_currentSecond <= 11) {
          _phase = BreathingPhase.hold;
          if (_currentSecond == 5) {
            _ttsService.speak("Hold for 7 seconds");
            _controller.animateTo(
              0.5,
              duration: const Duration(milliseconds: 500),
            );
          }
        } else if (_currentSecond <= 19) {
          _phase = BreathingPhase.exhale;
          if (_currentSecond == 12) {
            _ttsService.speak("Exhale slowly for 8 seconds");
            _controller.reverse();
          }
        } else {
          _currentSecond = 0;
          _totalCycles++;
          _ttsService.speak("Cycle $_totalCycles complete");

          if (_totalCycles >= 4) {
            timer.cancel();
            _ttsService.speak(
              "Excellent! 4 cycles complete. You're doing great!",
            );
            _phase = BreathingPhase.complete;
            _completeSession();
          }
        }
      });
    });
  }

  Color _getPhaseColor() {
    switch (_phase) {
      case BreathingPhase.inhale:
        return Color.lerp(
          const Color(0xFF00b4d8),
          const Color(0xFF0077b6),
          _colorAnimation.value,
        )!;
      case BreathingPhase.hold:
        return const Color(0xFF9d4edd);
      case BreathingPhase.exhale:
        return Color.lerp(
          const Color(0xFF38b000),
          const Color(0xFF008000),
          _colorAnimation.value,
        )!;
      case BreathingPhase.complete:
        return const Color(0xFFffb700);
    }
  }

  String _getPhaseText() {
    switch (_phase) {
      case BreathingPhase.inhale:
        return 'INHALE';
      case BreathingPhase.hold:
        return 'HOLD';
      case BreathingPhase.exhale:
        return 'EXHALE';
      case BreathingPhase.complete:
        return 'COMPLETE';
    }
  }

  String _getTimeRemaining() {
    switch (_phase) {
      case BreathingPhase.inhale:
        return '${5 - _currentSecond}s';
      case BreathingPhase.hold:
        return '${12 - _currentSecond}s';
      case BreathingPhase.exhale:
        return '${20 - _currentSecond}s';
      case BreathingPhase.complete:
        return '';
    }
  }

  void _togglePause() {
    setState(() {
      _isRunning = !_isRunning;
      if (_isRunning) {
        _startBreathingCycle();
      } else {
        _cycleTimer?.cancel();
        _ttsService.speak("Paused");
      }
    });
  }

  void _toggleGuide() {
    setState(() {
      _showGuide = !_showGuide;
    });
  }

  void _reset() {
    setState(() {
      _currentSecond = 0;
      _totalCycles = 0;
      _phase = BreathingPhase.inhale;
      _isRunning = true;
    });
    _cycleTimer?.cancel();
    _startBreathingCycle();
  }

  void _completeSession() {
    final sessionProvider = context.read<SessionProvider>();
    sessionProvider.saveSession(
      durationMinutes: 4,
      meditationType: '4-7-8 Breathing',
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _cycleTimer?.cancel();
    _audioService.stopSound();
    _ttsService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1a1a2e),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // Header
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.go('/breathing'),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    '4-7-8 Breathing',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: _toggleGuide,
                    icon: Icon(
                      _showGuide ? Icons.info : Icons.info_outline,
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                    onPressed: _togglePause,
                    icon: Icon(
                      _isRunning ? Icons.pause : Icons.play_arrow,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ],
              ),

              // Guide
              if (_showGuide)
                Container(
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(top: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '4-7-8 Technique',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Inhale for 4 seconds, hold for 7 seconds, exhale for 8 seconds. '
                        'Repeat 4 times. Great for anxiety and sleep.',
                        style: TextStyle(fontSize: 14, color: Colors.white70),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 40),

              // Main visualization
              Expanded(
                child: Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Progress ring
                      SizedBox(
                        width: 300,
                        height: 300,
                        child: CircularProgressIndicator(
                          value: _currentSecond / 20,
                          strokeWidth: 10,
                          backgroundColor: Colors.white.withOpacity(0.1),
                          valueColor: AlwaysStoppedAnimation(_getPhaseColor()),
                        ),
                      ),

                      // Animated circle
                      AnimatedBuilder(
                        animation: _controller,
                        builder: (context, child) {
                          return Transform.scale(
                            scale: _scaleAnimation.value,
                            child: Container(
                              width: 200,
                              height: 200,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: [
                                    _getPhaseColor(),
                                    _getPhaseColor().withOpacity(0.7),
                                  ],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _getPhaseColor().withOpacity(0.5),
                                    blurRadius: 30,
                                    spreadRadius: 10,
                                  ),
                                ],
                              ),
                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      _getPhaseText(),
                                      style: const TextStyle(
                                        fontSize: 28,
                                        fontWeight: FontWeight.w800,
                                        color: Colors.white,
                                        letterSpacing: 2,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    if (_phase != BreathingPhase.complete)
                                      Text(
                                        _getTimeRemaining(),
                                        style: const TextStyle(
                                          fontSize: 48,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.white,
                                        ),
                                      ),
                                    const SizedBox(height: 10),
                                    Text(
                                      'Cycle: $_totalCycles/4',
                                      style: const TextStyle(
                                        fontSize: 16,
                                        color: Colors.white70,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 40),

              // Phase indicators
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildPhaseIndicator(
                    'Inhale',
                    '4s',
                    isActive: _phase == BreathingPhase.inhale,
                    color: const Color(0xFF00b4d8),
                  ),
                  _buildPhaseIndicator(
                    'Hold',
                    '7s',
                    isActive: _phase == BreathingPhase.hold,
                    color: const Color(0xFF9d4edd),
                  ),
                  _buildPhaseIndicator(
                    'Exhale',
                    '8s',
                    isActive: _phase == BreathingPhase.exhale,
                    color: const Color(0xFF38b000),
                  ),
                ],
              ),

              const SizedBox(height: 30),

              // Controls
              if (_phase == BreathingPhase.complete)
                Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _reset,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFffb700),
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: const Text(
                          'START AGAIN',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: () => context.router.maybePop(),
                      child: const Text(
                        'BACK TO EXERCISES',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ],
                )
              else
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _reset,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white.withOpacity(0.1),
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: const Text(
                      'RESET',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPhaseIndicator(
    String label,
    String time, {
    required bool isActive,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: isActive ? color : Colors.white.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(
              color: color.withOpacity(isActive ? 0.8 : 0.3),
              width: 2,
            ),
          ),
          child: Center(
            child: Text(
              time,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: isActive ? Colors.white : color,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: isActive ? Colors.white : Colors.white70,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ],
    );
  }
}

enum BreathingPhase { inhale, hold, exhale, complete }
