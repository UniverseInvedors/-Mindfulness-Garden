// lib/features/breathing/exercises/alternate_nostril_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AlternateNostrilScreen extends StatefulWidget {
  const AlternateNostrilScreen({super.key});

  @override
  State<AlternateNostrilScreen> createState() => _AlternateNostrilScreenState();
}

class _AlternateNostrilScreenState extends State<AlternateNostrilScreen>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _breathController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  int _currentPhase = 0; // 0: inhale left, 1: hold, 2: exhale right, 3: inhale right, 4: hold, 5: exhale left
  int _roundsCompleted = 0;
  final int _totalRounds = 10;
  bool _isActive = false;

  final List<String> _phaseInstructions = [
    "Close right nostril, inhale through left",
    "Hold breath (both nostrils closed)",
    "Close left nostril, exhale through right",
    "Inhale through right nostril",
    "Hold breath",
    "Exhale through left nostril",
  ];

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.2).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _breathController = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    );

    _opacityAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _breathController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _breathController.dispose();
    super.dispose();
  }

  void _startExercise() {
    setState(() {
      _isActive = true;
      _roundsCompleted = 0;
      _currentPhase = 0;
    });
    _startPhase(0);
  }

  void _startPhase(int phase) {
    setState(() {
      _currentPhase = phase;
    });

    // Set duration based on phase
    Duration duration;
    if (phase == 1 || phase == 4) { // Hold phases
      duration = const Duration(seconds: 4);
    } else { // Inhale/exhale phases
      duration = const Duration(seconds: 4);
    }

    _breathController.duration = duration;
    _breathController.forward(from: 0).then((_) {
      _nextPhase();
    });
  }

  void _nextPhase() {
    if (!_isActive) return;

    int nextPhase = _currentPhase + 1;
    if (nextPhase >= 6) {
      // Completed one full round
      nextPhase = 0;
      setState(() {
        _roundsCompleted++;
      });

      if (_roundsCompleted >= _totalRounds) {
        _completeExercise();
        return;
      }
    }

    _startPhase(nextPhase);
  }

  void _pauseExercise() {
    setState(() {
      _isActive = false;
    });
    _breathController.stop();
  }

  void _resumeExercise() {
    setState(() {
      _isActive = true;
    });
    _breathController.forward();
  }

  void _resetExercise() {
    setState(() {
      _isActive = false;
      _roundsCompleted = 0;
      _currentPhase = 0;
    });
    _breathController.reset();
  }

  void _completeExercise() {
    _breathController.reset();
    setState(() {
      _isActive = false;
    });

    // Show completion dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text(
          'Exercise Complete! 🎉',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Great job! You\'ve completed 10 rounds of Alternate Nostril Breathing.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.go('/breathing');
            },
            child: const Text(
              'Done',
              style: TextStyle(color: Color(0xFF00b4d8)),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0a0a1a),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  const Text(
                    'Alternate Nostril',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            // Main content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    // Animation circle
                    AnimatedBuilder(
                      animation: _breathController,
                      builder: (context, child) {
                        return Container(
                          height: 250,
                          width: 250,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                const Color(0xFF9d4edd).withOpacity(0.7),
                                const Color(0xFF560bad).withOpacity(0.4),
                              ],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF9d4edd).withOpacity(0.3),
                                blurRadius: 30,
                                spreadRadius: _scaleAnimation.value * 5,
                              ),
                            ],
                          ),
                          child: Center(
                            child: AnimatedBuilder(
                              animation: _scaleAnimation,
                              builder: (context, child) {
                                return Transform.scale(
                                  scale: _scaleAnimation.value,
                                  child: Container(
                                    height: 150,
                                    width: 150,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white.withOpacity(0.1),
                                      border: Border.all(
                                        color: Colors.white.withOpacity(0.3),
                                        width: 2,
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        _getPhaseSymbol(),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 48,
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 40),

                    // Instruction text
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.1),
                        ),
                      ),
                      child: Column(
                        children: [
                          Text(
                            _phaseInstructions[_currentPhase],
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _currentPhase == 0 || _currentPhase == 3
                                      ? Colors.green
                                      : Colors.grey.withOpacity(0.3),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _currentPhase == 1 || _currentPhase == 4
                                      ? Colors.orange
                                      : Colors.grey.withOpacity(0.3),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _currentPhase == 2 || _currentPhase == 5
                                      ? Colors.blue
                                      : Colors.grey.withOpacity(0.3),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 40),

                    // Progress
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            const Color(0xFF9d4edd).withOpacity(0.2),
                            const Color(0xFF560bad).withOpacity(0.1),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        children: [
                          Text(
                            'Round $_roundsCompleted of $_totalRounds',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 10),
                          LinearProgressIndicator(
                            value: _roundsCompleted / _totalRounds,
                            backgroundColor: Colors.white.withOpacity(0.1),
                            valueColor: const AlwaysStoppedAnimation<Color>(
                              Color(0xFF9d4edd),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 40),

                    // Control buttons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (!_isActive && _roundsCompleted == 0)
                          _buildControlButton(
                            icon: Icons.play_arrow,
                            label: 'Start',
                            onPressed: _startExercise,
                            color: Colors.green,
                          )
                        else if (!_isActive && _roundsCompleted > 0)
                          _buildControlButton(
                            icon: Icons.play_arrow,
                            label: 'Resume',
                            onPressed: _resumeExercise,
                            color: Colors.orange,
                          )
                        else
                          _buildControlButton(
                            icon: Icons.pause,
                            label: 'Pause',
                            onPressed: _pauseExercise,
                            color: Colors.red,
                          ),
                        const SizedBox(width: 20),
                        if (_roundsCompleted > 0)
                          _buildControlButton(
                            icon: Icons.refresh,
                            label: 'Reset',
                            onPressed: _resetExercise,
                            color: Colors.blue,
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    required Color color,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: color.withOpacity(0.5)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getPhaseSymbol() {
    if (_currentPhase == 0 || _currentPhase == 3) return '⬆️'; // Inhale
    if (_currentPhase == 1 || _currentPhase == 4) return '⏸️'; // Hold
    return '⬇️'; // Exhale
  }
}