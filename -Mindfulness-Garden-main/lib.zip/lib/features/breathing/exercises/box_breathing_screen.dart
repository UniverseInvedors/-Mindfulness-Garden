import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:mindfulness_garden/core/services/audio_service.dart';
import 'package:mindfulness_garden/core/services/tts_service.dart';
import 'package:mindfulness_garden/presentation/providers/session_provider.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'dart:async';

@RoutePage()
class BoxBreathingScreen extends StatefulWidget {
  const BoxBreathingScreen({super.key});

  @override
  State<BoxBreathingScreen> createState() => _BoxBreathingScreenState();
}

class _BoxBreathingScreenState extends State<BoxBreathingScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _borderAnimation;
  late Animation<Color?> _colorAnimation;

  final AudioService _audioService = AudioService();
  final TtsService _ttsService = TtsService();

  Timer? _cycleTimer;
  int _currentSecond = 0;
  int _totalCycles = 0;
  BoxPhase _phase = BoxPhase.inhale;
  bool _isRunning = true;
  bool _showVisualGuide = true;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 16),
      vsync: this,
    );

    _borderAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 0.25), weight: 1),
      TweenSequenceItem(tween: Tween<double>(begin: 0.25, end: 0.5), weight: 1),
      TweenSequenceItem(tween: Tween<double>(begin: 0.5, end: 0.75), weight: 1),
      TweenSequenceItem(tween: Tween<double>(begin: 0.75, end: 1.0), weight: 1),
    ]).animate(_controller);

    _colorAnimation = ColorTween(
      begin: const Color(0xFF00b4d8),
      end: const Color(0xFF38b000),
    ).animate(_controller);

    _playAmbientSound();
    _startBoxBreathing();
  }

  void _playAmbientSound() async {
    await _audioService.playSound('piano');
  }

  void _startBoxBreathing() {
    _cycleTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isRunning) return;

      setState(() {
        _currentSecond++;

        // Box breathing: 4-4-4-4
        if (_currentSecond <= 4) {
          _phase = BoxPhase.inhale;
          if (_currentSecond == 1) {
            _ttsService.speak("Inhale for 4 seconds");
            _controller.animateTo(0.25, duration: const Duration(seconds: 4));
          }
        } else if (_currentSecond <= 8) {
          _phase = BoxPhase.holdInhale;
          if (_currentSecond == 5) {
            _ttsService.speak("Hold breath for 4 seconds");
          }
        } else if (_currentSecond <= 12) {
          _phase = BoxPhase.exhale;
          if (_currentSecond == 9) {
            _ttsService.speak("Exhale for 4 seconds");
            _controller.animateTo(0.75, duration: const Duration(seconds: 4));
          }
        } else if (_currentSecond <= 16) {
          _phase = BoxPhase.holdExhale;
          if (_currentSecond == 13) {
            _ttsService.speak("Hold empty for 4 seconds");
          }
        } else {
          _currentSecond = 0;
          _totalCycles++;
          _ttsService.speak("Box $_totalCycles complete");

          if (_totalCycles >= 4) {
            timer.cancel();
            _ttsService.speak(
              "Excellent! 4 boxes complete. You're focused and calm!",
            );
            _phase = BoxPhase.complete;
            _controller.animateTo(1.0, duration: const Duration(seconds: 1));
            _completeSession();
          }
        }
      });
    });
  }

  String _getPhaseText() {
    switch (_phase) {
      case BoxPhase.inhale:
        return 'INHALE';
      case BoxPhase.holdInhale:
        return 'HOLD';
      case BoxPhase.exhale:
        return 'EXHALE';
      case BoxPhase.holdExhale:
        return 'HOLD EMPTY';
      case BoxPhase.complete:
        return 'COMPLETE';
    }
  }

  String _getPhaseDescription() {
    switch (_phase) {
      case BoxPhase.inhale:
        return 'Breathe in slowly';
      case BoxPhase.holdInhale:
        return 'Hold your breath';
      case BoxPhase.exhale:
        return 'Release slowly';
      case BoxPhase.holdExhale:
        return 'Hold empty lungs';
      case BoxPhase.complete:
        return '4 boxes complete!';
    }
  }

  Color _getPhaseColor() {
    switch (_phase) {
      case BoxPhase.inhale:
        return const Color(0xFF00b4d8);
      case BoxPhase.holdInhale:
        return const Color(0xFF9d4edd);
      case BoxPhase.exhale:
        return const Color(0xFF38b000);
      case BoxPhase.holdExhale:
        return const Color(0xFFffb700);
      case BoxPhase.complete:
        return const Color(0xFFff6d00);
    }
  }

  IconData _getPhaseIcon() {
    switch (_phase) {
      case BoxPhase.inhale:
        return Icons.arrow_upward;
      case BoxPhase.holdInhale:
        return Icons.pause;
      case BoxPhase.exhale:
        return Icons.arrow_downward;
      case BoxPhase.holdExhale:
        return Icons.pause;
      case BoxPhase.complete:
        return Icons.check_circle;
    }
  }

  void _togglePause() {
    setState(() {
      _isRunning = !_isRunning;
      if (_isRunning) {
        _startBoxBreathing();
      } else {
        _cycleTimer?.cancel();
        _ttsService.speak("Paused");
      }
    });
  }

  void _toggleGuide() {
    setState(() {
      _showVisualGuide = !_showVisualGuide;
    });
  }

  void _reset() {
    setState(() {
      _currentSecond = 0;
      _totalCycles = 0;
      _phase = BoxPhase.inhale;
      _isRunning = true;
      _controller.reset();
    });
    _cycleTimer?.cancel();
    _startBoxBreathing();
  }

  void _completeSession() {
    final sessionProvider = context.read<SessionProvider>();
    sessionProvider.saveSession(
      durationMinutes: 5,
      meditationType: 'Box Breathing',
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _cycleTimer?.cancel();
    _audioService.stopSound();
    _ttsService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1a1a2e),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // Header
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.go('/breathing'),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'Box Breathing',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: _toggleGuide,
                    icon: Icon(
                      _showVisualGuide
                          ? Icons.visibility
                          : Icons.visibility_off,
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                    onPressed: _togglePause,
                    icon: Icon(
                      _isRunning ? Icons.pause : Icons.play_arrow,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ],
              ),

              // Guide
              if (_showVisualGuide)
                Container(
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(top: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Box Breathing Technique',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Inhale 4s → Hold 4s → Exhale 4s → Hold 4s. '
                        'Repeat 4 times. Excellent for focus and stress relief.',
                        style: TextStyle(fontSize: 14, color: Colors.white70),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 30),

              // Box Breathing Visualization
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedBuilder(
                        animation: _controller,
                        builder: (context, child) {
                          return SizedBox(
                            width: 300,
                            height: 300,
                            child: CustomPaint(
                              painter: BoxPainter(
                                progress: _borderAnimation.value,
                                color: _colorAnimation.value ?? Colors.blue,
                                phase: _phase,
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 40),

                      // Phase Info
                      Column(
                        children: [
                          Text(
                            _getPhaseText(),
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w800,
                              color: _getPhaseColor(),
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            _getPhaseDescription(),
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.white70,
                            ),
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                _getPhaseIcon(),
                                color: _getPhaseColor(),
                                size: 30,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                '${_currentSecond % 16}s / 16s',
                                style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'Box: $_totalCycles/4',
                            style: const TextStyle(
                              fontSize: 16,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // Phase Timeline
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildBoxPhase('Inhale', 4, BoxPhase.inhale),
                    _buildBoxPhase('Hold', 4, BoxPhase.holdInhale),
                    _buildBoxPhase('Exhale', 4, BoxPhase.exhale),
                    _buildBoxPhase('Hold', 4, BoxPhase.holdExhale),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Controls
              if (_phase == BoxPhase.complete)
                Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _reset,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFff6d00),
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: const Text(
                          'BOX BREATHE AGAIN',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: () => context.router.maybePop(),
                      child: const Text(
                        'TRY ANOTHER EXERCISE',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ],
                )
              else
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _reset,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white.withOpacity(0.1),
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: const Text(
                      'RESTART BOX',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBoxPhase(String label, int seconds, BoxPhase phase) {
    final isActive = _phase == phase;
    final color = _getPhaseColorForPhase(phase);

    return Column(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: isActive ? color : Colors.transparent,
            shape: BoxShape.circle,
            border: Border.all(
              color: color.withOpacity(isActive ? 1.0 : 0.3),
              width: 2,
            ),
          ),
          child: Center(
            child: Text(
              '$seconds',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: isActive ? Colors.white : color,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: isActive ? Colors.white : Colors.white70,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ],
    );
  }

  Color _getPhaseColorForPhase(BoxPhase phase) {
    switch (phase) {
      case BoxPhase.inhale:
        return const Color(0xFF00b4d8);
      case BoxPhase.holdInhale:
        return const Color(0xFF9d4edd);
      case BoxPhase.exhale:
        return const Color(0xFF38b000);
      case BoxPhase.holdExhale:
        return const Color(0xFFffb700);
      case BoxPhase.complete:
        return const Color(0xFFff6d00);
    }
  }
}

enum BoxPhase { inhale, holdInhale, exhale, holdExhale, complete }

class BoxPainter extends CustomPainter {
  final double progress;
  final Color color;
  final BoxPhase phase;

  BoxPainter({
    required this.progress,
    required this.color,
    required this.phase,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);

    // Draw background grid
    final gridPaint = Paint()
      ..color = Colors.white.withOpacity(0.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    // Draw horizontal and vertical lines
    canvas.drawLine(
      Offset(0, center.dy),
      Offset(size.width, center.dy),
      gridPaint,
    );
    canvas.drawLine(
      Offset(center.dx, 0),
      Offset(center.dx, size.height),
      gridPaint,
    );

    // Draw box outline
    final boxPaint = Paint()
      ..color = color.withOpacity(0.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final boxRect = Rect.fromCenter(
      center: center,
      width: size.width * 0.8,
      height: size.height * 0.8,
    );
    canvas.drawRect(boxRect, boxPaint);

    // Draw progress line
    final progressPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round;

    final progressPath = Path();
    final boxSize = size.width * 0.8;

    if (progress <= 0.25) {
      // Top edge (left to right)
      final startX = center.dx - boxSize / 2;
      final endX = startX + (progress * 4 * boxSize);
      progressPath.moveTo(startX, center.dy - boxSize / 2);
      progressPath.lineTo(endX, center.dy - boxSize / 2);
    } else if (progress <= 0.5) {
      // Right edge (top to bottom)
      progressPath.moveTo(center.dx - boxSize / 2, center.dy - boxSize / 2);
      progressPath.lineTo(center.dx + boxSize / 2, center.dy - boxSize / 2);

      final progressY =
          center.dy - boxSize / 2 + ((progress - 0.25) * 4 * boxSize);
      progressPath.lineTo(center.dx + boxSize / 2, progressY);
    } else if (progress <= 0.75) {
      // Bottom edge (right to left)
      progressPath.moveTo(center.dx - boxSize / 2, center.dy - boxSize / 2);
      progressPath.lineTo(center.dx + boxSize / 2, center.dy - boxSize / 2);
      progressPath.lineTo(center.dx + boxSize / 2, center.dy + boxSize / 2);

      final progressX =
          center.dx + boxSize / 2 - ((progress - 0.5) * 4 * boxSize);
      progressPath.lineTo(progressX, center.dy + boxSize / 2);
    } else {
      // Left edge (bottom to top)
      progressPath.moveTo(center.dx - boxSize / 2, center.dy - boxSize / 2);
      progressPath.lineTo(center.dx + boxSize / 2, center.dy - boxSize / 2);
      progressPath.lineTo(center.dx + boxSize / 2, center.dy + boxSize / 2);
      progressPath.lineTo(center.dx - boxSize / 2, center.dy + boxSize / 2);

      final progressY =
          center.dy + boxSize / 2 - ((progress - 0.75) * 4 * boxSize);
      progressPath.lineTo(center.dx - boxSize / 2, progressY);
    }

    canvas.drawPath(progressPath, progressPaint);

    // Draw current position indicator
    final indicatorPaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    Offset indicatorPosition;
    if (progress <= 0.25) {
      indicatorPosition = Offset(
        center.dx - boxSize / 2 + (progress * 4 * boxSize),
        center.dy - boxSize / 2,
      );
    } else if (progress <= 0.5) {
      indicatorPosition = Offset(
        center.dx + boxSize / 2,
        center.dy - boxSize / 2 + ((progress - 0.25) * 4 * boxSize),
      );
    } else if (progress <= 0.75) {
      indicatorPosition = Offset(
        center.dx + boxSize / 2 - ((progress - 0.5) * 4 * boxSize),
        center.dy + boxSize / 2,
      );
    } else {
      indicatorPosition = Offset(
        center.dx - boxSize / 2,
        center.dy + boxSize / 2 - ((progress - 0.75) * 4 * boxSize),
      );
    }

    canvas.drawCircle(indicatorPosition, 12, indicatorPaint);
  }

  @override
  bool shouldRepaint(covariant BoxPainter oldDelegate) {
    return progress != oldDelegate.progress ||
        color != oldDelegate.color ||
        phase != oldDelegate.phase;
  }
}
