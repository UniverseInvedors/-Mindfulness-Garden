import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:mindfulness_garden/core/services/audio_service.dart';
import 'package:mindfulness_garden/core/services/tts_service.dart';
import 'package:mindfulness_garden/presentation/providers/session_provider.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'dart:async';
import 'package:lottie/lottie.dart';

@RoutePage()
class OngoBreathingScreen extends StatefulWidget {
  const OngoBreathingScreen({super.key});

  @override
  State<OngoBreathingScreen> createState() => _OngoBreathingScreenState();
}

class _OngoBreathingScreenState extends State<OngoBreathingScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  final AudioService _audioService = AudioService();
  final TtsService _ttsService = TtsService();

  Timer? _breathTimer;
  int _cycleCount = 0;
  bool _isPlaying = false;
  bool _isPaused = false;
  BreathingPhase _phase = BreathingPhase.intro;
  String _currentInstruction = '';
  String _currentVoiceLine = '';
  List<String> _languages = ['English', 'Spanish'];
  String _selectedLanguage = 'English';

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _fadeAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _playAmbientSound();
  }

  void _playAmbientSound() async {
    await _audioService.playSound('piano');
  }

  void _startExercise() async {
    // Set language for TTS
    await _ttsService.setLanguage(
      _selectedLanguage == 'Spanish' ? 'es-ES' : 'en-US',
    );

    // Start with intro
    _setPhase(BreathingPhase.intro);
    await _speak(
      "Hi, it's Ongo. We are going to do breathing exercises now. "
      "You can do these anytime you are having a difficult time. "
      "Remember, Just breathe.",
    );

    await Future.delayed(const Duration(seconds: 2));

    // Start breathing cycles
    _startBreathingCycles();
  }

  void _startBreathingCycles() {
    setState(() {
      _isPlaying = true;
      _phase = BreathingPhase.breathing;
    });

    _breathTimer = Timer.periodic(const Duration(seconds: 10), (timer) async {
      if (_cycleCount >= 4) {
        timer.cancel();
        _setPhase(BreathingPhase.rest);
        await _speak("Great job! Rest now for 5 seconds.");
        await Future.delayed(const Duration(seconds: 5));
        _setPhase(BreathingPhase.complete);
        _completeSession();
        return;
      }

      if (!_isPaused) {
        _cycleCount++;

        // Inhale phase
        _setInstruction("Breathe in...");
        await _speak("Ok, let's inhale now");
        await _animateBreath(inhale: true);
        await Future.delayed(const Duration(seconds: 2));

        // Hold phase
        _setInstruction("Hold...");
        await _speak("Hold for a few seconds");
        await Future.delayed(const Duration(seconds: 3));

        // Exhale phase
        _setInstruction("Let it go...");
        await _speak("Let it go, Let it go");
        await _animateBreath(inhale: false);

        await Future.delayed(const Duration(seconds: 2));
      }
    });
  }

  Future<void> _animateBreath({required bool inhale}) async {
    _controller.reset();
    if (inhale) {
      await _controller.forward();
    } else {
      await _controller.reverse();
    }
  }

  Future<void> _speak(String text) async {
    _setVoiceLine(text);
    await _ttsService.speak(text);
  }

  void _setPhase(BreathingPhase phase) {
    setState(() {
      _phase = phase;
    });
  }

  void _setInstruction(String instruction) {
    setState(() {
      _currentInstruction = instruction;
    });
  }

  void _setVoiceLine(String voiceLine) {
    setState(() {
      _currentVoiceLine = voiceLine;
    });
  }

  void _togglePause() {
    setState(() {
      _isPaused = !_isPaused;
      if (_isPaused) {
        _breathTimer?.cancel();
        _controller.stop();
        _setInstruction("Paused");
      } else {
        _startBreathingCycles();
      }
    });
  }

  void _completeSession() {
    final sessionProvider = context.read<SessionProvider>();
    sessionProvider.saveSession(
      durationMinutes: 5,
      meditationType: 'Ongo Breathing',
    );
  }

  void _playAgain() {
    setState(() {
      _cycleCount = 0;
      _phase = BreathingPhase.intro;
      _isPlaying = false;
      _isPaused = false;
      _breathTimer?.cancel();
    });
    _startExercise();
  }

  Color _getPhaseColor() {
    switch (_phase) {
      case BreathingPhase.intro:
        return Colors.purple;
      case BreathingPhase.breathing:
        return Colors.blue;
      case BreathingPhase.rest:
        return Colors.orange;
      case BreathingPhase.complete:
        return Colors.green;
    }
  }

  String _getPhaseText() {
    switch (_phase) {
      case BreathingPhase.intro:
        return 'INTRODUCTION';
      case BreathingPhase.breathing:
        return 'BREATHING';
      case BreathingPhase.rest:
        return 'REST';
      case BreathingPhase.complete:
        return 'COMPLETE';
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _breathTimer?.cancel();
    _audioService.stopSound();
    _ttsService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1a1a2e),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // Header with language selection
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.go('/breathing'),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'Ongo Breathing',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const Spacer(),
                  DropdownButton<String>(
                    value: _selectedLanguage,
                    dropdownColor: const Color(0xFF2d2d44),
                    style: const TextStyle(color: Colors.white),
                    items: _languages.map((language) {
                      return DropdownMenuItem(
                        value: language,
                        child: Text(language),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedLanguage = value!;
                      });
                    },
                  ),
                ],
              ),

              const SizedBox(height: 30),

              // Main visualization
              Expanded(
                child: Center(
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          // Background glow
                          Container(
                            width: 300,
                            height: 300,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  _getPhaseColor().withOpacity(
                                    _fadeAnimation.value * 0.3,
                                  ),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),

                          // Animated circle
                          Transform.scale(
                            scale: _scaleAnimation.value,
                            child: Container(
                              width: 200,
                              height: 200,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: [
                                    _getPhaseColor(),
                                    _getPhaseColor().withOpacity(0.7),
                                  ],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _getPhaseColor().withOpacity(0.5),
                                    blurRadius: 30,
                                    spreadRadius: 10,
                                  ),
                                ],
                              ),
                              child: Center(
                                child: _phase == BreathingPhase.complete
                                    ? Lottie.asset(
                                        'assets/animations/celebration.json',
                                        width: 100,
                                        height: 100,
                                      )
                                    : Icon(
                                        _getPhaseIcon(),
                                        size: 60,
                                        color: Colors.white,
                                      ),
                              ),
                            ),
                          ),

                          // Instruction and cycle count
                          Positioned(
                            bottom: 50,
                            child: Column(
                              children: [
                                Text(
                                  _currentInstruction,
                                  style: const TextStyle(
                                    fontSize: 32,
                                    fontWeight: FontWeight.w800,
                                    color: Colors.white,
                                    letterSpacing: 2,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  'Cycle: $_cycleCount/4',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white.withOpacity(0.8),
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  _getPhaseText(),
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: _getPhaseColor(),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),

              const SizedBox(height: 40),

              // Voice line display
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.record_voice_over, color: Colors.white),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _currentVoiceLine,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white.withOpacity(0.9),
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Controls
              if (_phase == BreathingPhase.complete)
                Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _playAgain,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF00b4d8),
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: const Text(
                          'PLAY AGAIN',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: () => context.router.maybePop(),
                      child: const Text(
                        'BACK TO EXERCISES',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ],
                )
              else if (_phase == BreathingPhase.rest)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: const Text(
                      'REST NOW',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                )
              else
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    if (!_isPlaying)
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _startExercise,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                          child: const Text(
                            'START',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      )
                    else
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _togglePause,
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                _isPaused ? Colors.green : Colors.orange,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                          child: Text(
                            _isPaused ? 'RESUME' : 'PAUSE',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getPhaseIcon() {
    switch (_phase) {
      case BreathingPhase.intro:
        return Icons.psychology;
      case BreathingPhase.breathing:
        return Icons.air;
      case BreathingPhase.rest:
        return Icons.bedtime;
      case BreathingPhase.complete:
        return Icons.check_circle;
    }
  }
}

enum BreathingPhase { intro, breathing, rest, complete }
