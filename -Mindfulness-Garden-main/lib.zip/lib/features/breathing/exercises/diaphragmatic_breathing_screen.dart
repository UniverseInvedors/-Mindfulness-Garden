// lib/features/breathing/exercises/diaphragmatic_breathing_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class DiaphragmaticBreathingScreen extends StatefulWidget {
  const DiaphragmaticBreathingScreen({super.key});

  @override
  State<DiaphragmaticBreathingScreen> createState() => _DiaphragmaticBreathingScreenState();
}

class _DiaphragmaticBreathingScreenState extends State<DiaphragmaticBreathingScreen>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  int _cycleCount = 0;
  bool _isActive = false;
  String _currentPhase = 'inhale';

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.5).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _opacityAnimation = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState(() {
          _currentPhase = 'exhale';
        });
        _controller.reverse();
      } else if (status == AnimationStatus.dismissed) {
        setState(() {
          _currentPhase = 'inhale';
          _cycleCount++;
        });
        if (_isActive && _cycleCount < 20) {
          _controller.forward();
        } else if (_cycleCount >= 20) {
          _completeExercise();
        }
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _startExercise() {
    setState(() {
      _isActive = true;
      _cycleCount = 0;
      _currentPhase = 'inhale';
    });
    _controller.forward();
  }

  void _pauseExercise() {
    setState(() {
      _isActive = false;
    });
    _controller.stop();
  }

  void _resumeExercise() {
    setState(() {
      _isActive = true;
    });
    if (_currentPhase == 'inhale') {
      _controller.forward();
    } else {
      _controller.reverse();
    }
  }

  void _resetExercise() {
    setState(() {
      _isActive = false;
      _cycleCount = 0;
      _currentPhase = 'inhale';
    });
    _controller.reset();
  }

  void _completeExercise() {
    _controller.reset();
    setState(() {
      _isActive = false;
    });

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text(
          'Great Job! 🎉',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'You\'ve completed 20 cycles of diaphragmatic breathing.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.go('/breathing');
            },
            child: const Text(
              'Done',
              style: TextStyle(color: Color(0xFF00b4d8)),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0a0a1a),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => context.pop(),
        ),
        title: const Text(
          'Diaphragmatic Breathing',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Expanded(
                child: Center(
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          // Outer glow
                          Container(
                            width: 300,
                            height: 300,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF4361ee).withOpacity(_opacityAnimation.value),
                                  blurRadius: 50,
                                  spreadRadius: 20,
                                ),
                              ],
                            ),
                          ),

                          // Breathing circle
                          Transform.scale(
                            scale: _scaleAnimation.value,
                            child: Container(
                              width: 200,
                              height: 200,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: [
                                    const Color(0xFF4361ee),
                                    const Color(0xFF3a0ca3),
                                  ],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFF4361ee).withOpacity(0.5),
                                    blurRadius: 30,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              child: Center(
                                child: Text(
                                  _currentPhase == 'inhale' ? '⬆️' : '⬇️',
                                  style: const TextStyle(fontSize: 48),
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),

              // Instructions
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  children: [
                    Text(
                      _currentPhase == 'inhale'
                          ? 'Breathe in deeply through your nose'
                          : 'Exhale slowly through your mouth',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Place one hand on your chest and one on your belly',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 16,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              // Progress
              Text(
                'Cycle $_cycleCount of 20',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                ),
              ),

              const SizedBox(height: 20),
              LinearProgressIndicator(
                value: _cycleCount / 20,
                backgroundColor: Colors.white.withOpacity(0.1),
                valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF4361ee)),
              ),

              const SizedBox(height: 30),

              // Controls
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (!_isActive && _cycleCount == 0)
                    ElevatedButton(
                      onPressed: _startExercise,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      ),
                      child: const Text('Start'),
                    )
                  else if (!_isActive && _cycleCount > 0)
                    ElevatedButton(
                      onPressed: _resumeExercise,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      ),
                      child: const Text('Resume'),
                    )
                  else
                    ElevatedButton(
                      onPressed: _pauseExercise,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      ),
                      child: const Text('Pause'),
                    ),
                  const SizedBox(width: 20),
                  if (_cycleCount > 0)
                    ElevatedButton(
                      onPressed: _resetExercise,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      ),
                      child: const Text('Reset'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}