import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_animate/flutter_animate.dart';

class MeditationScreen extends StatefulWidget {
  const MeditationScreen({super.key});

  @override
  State<MeditationScreen> createState() => _MeditationScreenState();
}

class _MeditationScreenState extends State<MeditationScreen>
    with SingleTickerProviderStateMixin {
  final AudioPlayer _audioPlayer = AudioPlayer();
  late AnimationController _animationController;
  late Animation<double> _breathAnimation;
  late Animation<Color?> _colorAnimation;

  bool _isPlaying = false;
  final Duration _duration = const Duration(minutes: 10);
  Duration _position = Duration.zero;
  int _breathCycle = 0;
  String _breathPhase = 'Inhale';
  double _breathProgress = 0.0;
  int _selectedSound = 0;

  final List<Map<String, dynamic>> _sounds = [
    {
      'name': 'Forest',
      'icon': Icons.forest,
      'color': Colors.green,
      'description': 'Nature sounds',
    },
    {
      'name': 'Ocean',
      'icon': Icons.waves,
      'color': Colors.blue,
      'description': 'Waves crashing',
    },
    {
      'name': 'Rain',
      'icon': Icons.water_drop,
      'color': Colors.blueAccent,
      'description': 'Gentle rainfall',
    },
    {
      'name': 'Bowl',
      'icon': Icons.music_note,
      'color': Colors.orange,
      'description': 'Singing bowl',
    },
  ];

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      duration: const Duration(seconds: 8),
      vsync: this,
    )..repeat();

    _breathAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0, 0.5, curve: Curves.easeInOut),
      ),
    );

    _colorAnimation = ColorTween(
      begin: Colors.blue.withOpacity(0.3),
      end: Colors.green.withOpacity(0.3),
    ).animate(_animationController);

    _setupBreathingCycle();
  }

  void _setupBreathingCycle() {
    _animationController.addListener(() {
      final value = _animationController.value;
      if (value < 0.5) {
        // Inhale phase
        setState(() {
          _breathPhase = 'Inhale';
          _breathProgress = value * 2;
        });
      } else {
        // Exhale phase
        setState(() {
          _breathPhase = 'Exhale';
          _breathProgress = (value - 0.5) * 2;
        });
      }

      // Complete cycle
      if (value == 1.0) {
        setState(() {
          _breathCycle++;
        });
      }
    });
  }

  Future<void> _togglePlayback() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
      _animationController.stop();
    } else {
      // In production: await _audioPlayer.play(AssetSource('sounds/ambient.mp3'));
      await Future.delayed(const Duration(milliseconds: 300));
      _animationController.repeat();
    }
    setState(() {
      _isPlaying = !_isPlaying;
    });
  }

  void _selectSound(int index) {
    setState(() {
      _selectedSound = index;
    });
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _animationController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0a0a1a),
      body: SafeArea(
        child: Stack(
          children: [
            // Animated Background
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _colorAnimation,
                builder: (context, child) {
                  return Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment.center,
                        radius: 1.5,
                        colors: [
                          _colorAnimation.value ?? Colors.blue.withOpacity(0.1),
                          const Color(0xFF0a0a1a),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            // Content
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Header
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.of(context).pop(),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.arrow_back, color: Colors.white),
                        ),
                      ),
                      const Spacer(),
                      const Text(
                        'Meditation',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.more_vert, color: Colors.white),
                      ),
                    ],
                  ),

                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Timer and Breath Info
                        _buildTimerAndBreathInfo(),
                        const SizedBox(height: 40),

                        // Breathing Visualizer
                        _buildBreathingVisualizer(),
                        const SizedBox(height: 40),

                        // Controls
                        _buildControls(),
                        const SizedBox(height: 40),

                        // Sound Options
                        _buildSoundOptions(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimerAndBreathInfo() {
    return Column(
      children: [
        Text(
          _formatDuration(_position),
          style: const TextStyle(
            fontSize: 48,
            fontWeight: FontWeight.w300,
            color: Colors.white,
            fontFamily: 'RobotoMono',
          ),
        ),
        const SizedBox(height: 8),
        Text(
          _breathPhase,
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Cycle $_breathCycle',
          style: TextStyle(
            fontSize: 16,
            color: Colors.white.withOpacity(0.7),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Breath Awareness Meditation',
          style: TextStyle(
            fontSize: 16,
            color: Colors.white.withOpacity(0.8),
          ),
        ),
      ],
    );
  }

  Widget _buildBreathingVisualizer() {
    return AnimatedBuilder(
      animation: _breathAnimation,
      builder: (context, child) {
        return Container(
          width: 200,
          height: 200,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: Colors.white.withOpacity(0.2),
              width: 2,
            ),
          ),
          child: Stack(
            children: [
              // Breathing circles
              for (int i = 0; i < 3; i++)
                Positioned.fill(
                  child: Center(
                    child: Container(
                      width: 100 + (i * 20) + (_breathProgress * 40),
                      height: 100 + (i * 20) + (_breathProgress * 40),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.1 + (i * 0.1)),
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                ),

              // Center dot
              Center(
                child: Container(
                  width: 20 + (_breathProgress * 10),
                  height: 20 + (_breathProgress * 10),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _breathPhase == 'Inhale'
                        ? Colors.blue.withOpacity(0.8)
                        : Colors.green.withOpacity(0.8),
                    boxShadow: [
                      BoxShadow(
                        color: _breathPhase == 'Inhale'
                            ? Colors.blue.withOpacity(0.5)
                            : Colors.green.withOpacity(0.5),
                        blurRadius: 20,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Rewind
        GestureDetector(
          onTap: () {
            // Skip back 30 seconds
          },
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.replay_30, color: Colors.white),
          ),
        ),
        const SizedBox(width: 32),

        // Main Play Button
        GestureDetector(
          onTap: _togglePlayback,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: _isPlaying
                    ? [
                  Colors.red.withOpacity(0.8),
                  Colors.red.withOpacity(0.6),
                ]
                    : [
                  Colors.blue.withOpacity(0.8),
                  Colors.purple.withOpacity(0.6),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: (_isPlaying ? Colors.red : Colors.blue).withOpacity(0.4),
                  blurRadius: 20,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Icon(
              _isPlaying ? Icons.pause : Icons.play_arrow,
              size: 40,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(width: 32),

        // Forward
        GestureDetector(
          onTap: () {
            // Skip forward 30 seconds
          },
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.forward_30, color: Colors.white),
          ),
        ),
      ],
    );
  }

  Widget _buildSoundOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            'AMBIENT SOUNDS',
            style: TextStyle(
              fontSize: 12,
              color: Colors.white.withOpacity(0.6),
              letterSpacing: 1.5,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 100,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _sounds.length,
            separatorBuilder: (context, index) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              final sound = _sounds[index];
              final isSelected = _selectedSound == index;

              return GestureDetector(
                onTap: () => _selectSound(index),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 80,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? sound['color'].withOpacity(0.2)
                        : Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected
                          ? sound['color']
                          : Colors.white.withOpacity(0.1),
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        sound['icon'],
                        size: 30,
                        color: isSelected ? sound['color'] : Colors.white.withOpacity(0.7),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        sound['name'],
                        style: TextStyle(
                          fontSize: 12,
                          color: isSelected ? Colors.white : Colors.white.withOpacity(0.7),
                          fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
