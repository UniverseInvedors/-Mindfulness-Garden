import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';

class GuidedMeditationScreen extends StatefulWidget {
  const GuidedMeditationScreen({super.key});

  @override
  State<GuidedMeditationScreen> createState() => _GuidedMeditationScreenState();
}

class _GuidedMeditationScreenState extends State<GuidedMeditationScreen> {
  List<Map<String, dynamic>> _sessions = [];
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  int? _selectedSessionId;
  bool _isLoading = false;
  Map<int, bool> _favorites = {};

  @override
  void initState() {
    super.initState();
    _loadSessions();
  }

  Future<void> _loadSessions() async {
    _sessions = [
      {
        'id': 1,
        'title': 'Morning Mindfulness',
        'teacher': 'Sarah Johnson',
        'duration': const Duration(minutes: 10),
        'category': 'Morning',
        'difficulty': 'Beginner',
        'description': 'Start your day with clarity and peace',
        'thumbnail': 'assets/meditation/morning.jpg',
        'videoUrl': 'assets/videos/morning_meditation.mp4',
        'rating': 4.8,
        'plays': 1245,
      },
      {
        'id': 2,
        'title': 'Stress Release',
        'teacher': 'Michael Chen',
        'duration': const Duration(minutes: 15),
        'category': 'Stress Relief',
        'difficulty': 'Intermediate',
        'description': 'Release tension and find calm',
        'thumbnail': 'assets/meditation/stress.jpg',
        'videoUrl': 'assets/videos/stress_release.mp4',
        'rating': 4.9,
        'plays': 892,
      },
      {
        'id': 3,
        'title': 'Deep Sleep',
        'teacher': 'Emma Wilson',
        'duration': const Duration(minutes: 20),
        'category': 'Sleep',
        'difficulty': 'All Levels',
        'description': 'Gentle guidance into restful sleep',
        'thumbnail': 'assets/meditation/sleep.jpg',
        'videoUrl': 'assets/videos/deep_sleep.mp4',
        'rating': 4.7,
        'plays': 1567,
      },
      {
        'id': 4,
        'title': 'Focus & Concentration',
        'teacher': 'David Park',
        'duration': const Duration(minutes: 12),
        'category': 'Focus',
        'difficulty': 'Advanced',
        'description': 'Sharpen your mind and attention',
        'thumbnail': 'assets/meditation/focus.jpg',
        'videoUrl': 'assets/videos/focus_concentration.mp4',
        'rating': 4.6,
        'plays': 734,
      },
      {
        'id': 5,
        'title': 'Anxiety Relief',
        'teacher': 'Lisa Taylor',
        'duration': const Duration(minutes: 8),
        'category': 'Anxiety',
        'difficulty': 'Beginner',
        'description': 'Calm your anxious thoughts',
        'thumbnail': 'assets/meditation/anxiety.jpg',
        'videoUrl': 'assets/videos/anxiety_relief.mp4',
        'rating': 4.9,
        'plays': 1123,
      },
      {
        'id': 6,
        'title': 'Body Scan',
        'teacher': 'Robert Kim',
        'duration': const Duration(minutes: 18),
        'category': 'Body Awareness',
        'difficulty': 'Intermediate',
        'description': 'Connect with your body sensations',
        'thumbnail': 'assets/meditation/body.jpg',
        'videoUrl': 'assets/videos/body_scan.mp4',
        'rating': 4.8,
        'plays': 987,
      },
    ];
  }

  Future<void> _playSession(Map<String, dynamic> session) async {
    setState(() {
      _isLoading = true;
    });

    if (_chewieController != null) {
      _chewieController!.dispose();
      _chewieController = null;
    }

    if (_videoController != null) {
      await _videoController!.dispose();
      _videoController = null;
    }


    try {
      // For demo, use a placeholder. In production, use session['videoUrl']
      _videoController = VideoPlayerController.asset(
        'assets/videos/meditation_demo.mp4',
      );

      await _videoController!.initialize();

      _chewieController = ChewieController(
        videoPlayerController: _videoController!,
        autoPlay: true,
        looping: false,
        showControls: true,
        allowMuting: true,
        allowPlaybackSpeedChanging: true,
        playbackSpeeds: [0.5, 0.75, 1.0, 1.25, 1.5, 2.0],
        materialProgressColors: ChewieProgressColors(
          playedColor: const Color(0xFF4361ee),
          handleColor: const Color(0xFF4361ee),
          backgroundColor: Colors.grey.withOpacity(0.3),
          bufferedColor: Colors.grey.withOpacity(0.6),
        ),
        placeholder: Container(
          color: const Color(0xFF0a0a1a),
          child: const Center(
            child: CircularProgressIndicator(
              color: Colors.white,
            ),
          ),
        ),
        errorBuilder: (context, errorMessage) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error, color: Colors.white, size: 50),
                const SizedBox(height: 16),
                Text(
                  'Error loading video',
                  style: TextStyle(color: Colors.white.withOpacity(0.8)),
                ),
                const SizedBox(height: 8),
                Text(
                  errorMessage,
                  style: TextStyle(color: Colors.white.withOpacity(0.6)),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      );

      setState(() {
        _selectedSessionId = session['id'];
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      // Show error
    }
  }

  void _toggleFavorite(int sessionId) {
    setState(() {
      _favorites[sessionId] = !(_favorites[sessionId] ?? false);
    });
  }

  void _downloadSession(Map<String, dynamic> session) {
    // Implement download functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Downloading ${session['title']}...'),
        backgroundColor: const Color(0xFF4361ee),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '${minutes}:${seconds.toString().padLeft(2, '0')}';
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'morning':
        return const Color(0xFFff9e00);
      case 'stress relief':
        return const Color(0xFFf72585);
      case 'sleep':
        return const Color(0xFF560bad);
      case 'focus':
        return const Color(0xFF4361ee);
      case 'anxiety':
        return const Color(0xFF7209b7);
      case 'body awareness':
        return const Color(0xFF4cc9f0);
      default:
        return const Color(0xFF4361ee);
    }
  }

  Widget _buildCategoryChip(String category) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: _getCategoryColor(category).withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _getCategoryColor(category).withOpacity(0.3),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: _getCategoryColor(category),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            category,
            style: TextStyle(
              fontSize: 12,
              color: _getCategoryColor(category),
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0a0a1a),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Guided Meditation',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          'Expert-led sessions',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.white.withOpacity(0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.search, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),

            // Video Player Section
            Expanded(
              child: Stack(
                children: [
                  // Background
                  Positioned.fill(
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF0a0a1a),
                            Color(0xFF1a1a2e),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // Video Player
                  if (_chewieController != null)
                    Positioned.fill(
                      child: Chewie(controller: _chewieController!),
                    )
                  else
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              const Color(0xFF4361ee).withOpacity(0.2),
                              const Color(0xFF7209b7).withOpacity(0.2),
                            ],
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.play_circle_filled,
                              size: 80,
                              color: Colors.white,
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              'Select a meditation to begin',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '${_sessions.length} sessions available',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white.withOpacity(0.7),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                  // Loading Overlay
                  if (_isLoading)
                    Positioned.fill(
                      child: Container(
                        color: Colors.black.withOpacity(0.8),
                        child: const Center(
                          child: CircularProgressIndicator(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),

                  // Session Info (if playing)
                  if (_selectedSessionId != null && !_isLoading)
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.8),
                            ],
                          ),
                        ),
                        child: _buildSessionInfo(_selectedSessionId!),
                      ),
                    ),
                ],
              ),
            ),

            // Sessions List
            Container(
              height: 280,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(30),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text(
                        'Meditation Library',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${_sessions.length} sessions',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white.withOpacity(0.7),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _sessions.length,
                      separatorBuilder: (context, index) =>
                      const SizedBox(width: 16),
                      itemBuilder: (context, index) {
                        final session = _sessions[index];
                        return _buildSessionCard(session);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionInfo(int sessionId) {
    final session =
    _sessions.firstWhere((s) => s['id'] == sessionId, orElse: () => {});

    return Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: _getCategoryColor(session['category']).withOpacity(0.2),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(
            Icons.play_arrow,
            color: _getCategoryColor(session['category']),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                session['title'],
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                session['teacher'],
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.white.withOpacity(0.7),
                ),
              ),
            ],
          ),
        ),
        IconButton(
          onPressed: () => _toggleFavorite(sessionId),
          icon: Icon(
            _favorites[sessionId] ?? false
                ? Icons.favorite
                : Icons.favorite_border,
            color: _favorites[sessionId] ?? false ? Colors.red : Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildSessionCard(Map<String, dynamic> session) {
    final isSelected = _selectedSessionId == session['id'];
    final isFavorite = _favorites[session['id']] ?? false;

    return GestureDetector(
      onTap: () => _playSession(session),
      child: Container(
        width: 200,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? const Color(0xFF4361ee)
                : Colors.white.withOpacity(0.1),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Thumbnail
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(20),
                ),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    _getCategoryColor(session['category']),
                    _getCategoryColor(session['category']).withOpacity(0.7),
                  ],
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    bottom: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        _formatDuration(session['duration']),
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  if (isFavorite)
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.6),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.favorite,
                          size: 16,
                          color: Colors.red,
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // Session Info
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          session['title'],
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.play_arrow,
                          size: 16,
                          color: Colors.white.withOpacity(0.7),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    session['teacher'],
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white.withOpacity(0.7),
                    ),
                  ),
                  const SizedBox(height: 8),
                  _buildCategoryChip(session['category']),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(
                        Icons.star,
                        size: 14,
                        color: Colors.yellow,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${session['rating']}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white.withOpacity(0.8),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Icon(
                        Icons.play_arrow,
                        size: 14,
                        color: Colors.white.withOpacity(0.6),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${session['plays']}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white.withOpacity(0.6),
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () => _downloadSession(session),
                        icon: Icon(
                          Icons.download,
                          size: 18,
                          color: Colors.white.withOpacity(0.6),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
