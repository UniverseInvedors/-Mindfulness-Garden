import 'package:flutter/material.dart';
import 'package:mindfulness_garden/core/themes/app_theme.dart';

class MoodTrackerScreen extends StatefulWidget {
  const MoodTrackerScreen({super.key});

  @override
  State<MoodTrackerScreen> createState() => _MoodTrackerScreenState();
}

class _MoodTrackerScreenState extends State<MoodTrackerScreen> {
  final List<Map<String, dynamic>> _moods = [
    {'emoji': '😢', 'label': 'Sad', 'color': Colors.blue},
    {'emoji': '😐', 'label': 'Neutral', 'color': Colors.grey},
    {'emoji': '🙂', 'label': 'Good', 'color': Colors.green},
    {'emoji': '😊', 'label': 'Happy', 'color': Colors.yellow},
    {'emoji': '😄', 'label': 'Great', 'color': Colors.orange},
    {'emoji': '🤩', 'label': 'Awesome', 'color': Colors.pink},
  ];

  String _selectedMood = '';
  int _selectedRating = 3;
  final TextEditingController _noteController = TextEditingController();
  final List<String> _selectedTags = [];

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _saveMood() async {
    if (_selectedMood.isEmpty) {
      _showSnackBar('Please select a mood');
      return;
    }

    // Save logic here
    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      _showSnackBar('Mood saved successfully!');
      Navigator.of(context).pop();
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mood Tracker'),
        actions: [
          IconButton(
            onPressed: _saveMood,
            icon: const Icon(Icons.check),
            tooltip: 'Save',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Text(
              'How are you feeling today?',
              style: textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Track your emotions to understand patterns',
              style: textTheme.bodyMedium?.copyWith(
                color: colors.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 32),

            // Mood Selection
            _buildMoodSelection(colors, textTheme),
            const SizedBox(height: 32),

            // Rating
            _buildRatingSelection(colors, textTheme),
            const SizedBox(height: 32),

            // Tags
            _buildTagsSelection(colors, textTheme),
            const SizedBox(height: 32),

            // Note
            _buildNoteInput(colors, textTheme),
            const SizedBox(height: 32),

            // Save Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveMood,
                child: const Text('Save Mood Entry'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMoodSelection(ColorScheme colors, TextTheme textTheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Select Mood',
          style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 16),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.2,
          ),
          itemCount: _moods.length,
          itemBuilder: (context, index) {
            final mood = _moods[index];
            final isSelected = _selectedMood == mood['label'];

            return GestureDetector(
              onTap: () {
                setState(() {
                  _selectedMood = mood['label'];
                });
              },
              child: Container(
                decoration: BoxDecoration(
                  color: isSelected
                      ? (mood['color'] as Color).withAlpha(20)
                      : colors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isSelected
                        ? mood['color'] as Color
                        : colors.outlineVariant,
                    width: isSelected ? 2 : 1,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: (mood['color'] as Color).withAlpha(40),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      mood['emoji'] as String,
                      style: const TextStyle(fontSize: 28),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      mood['label'] as String,
                      style: textTheme.bodyMedium?.copyWith(
                        color: isSelected
                            ? mood['color'] as Color
                            : colors.onSurface,
                        fontWeight: isSelected
                            ? FontWeight.w600
                            : FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildRatingSelection(ColorScheme colors, TextTheme textTheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Intensity (1-5)',
          style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 16),
        Slider(
          value: _selectedRating.toDouble(),
          min: 1,
          max: 5,
          divisions: 4,
          label: _selectedRating.toString(),
          onChanged: (value) {
            setState(() {
              _selectedRating = value.toInt();
            });
          },
          activeColor: colors.primary,
          inactiveColor: colors.surfaceVariant,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(5, (index) {
            final rating = index + 1;
            final isSelected = rating <= _selectedRating;

            return GestureDetector(
              onTap: () {
                setState(() {
                  _selectedRating = rating;
                });
              },
              child: Column(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: isSelected
                          ? colors.primary
                          : colors.surfaceVariant,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      isSelected ? Icons.star : Icons.star_border,
                      color: isSelected
                          ? colors.onPrimary
                          : colors.onSurfaceVariant,
                      size: 20,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    rating.toString(),
                    style: textTheme.bodySmall?.copyWith(
                      color: isSelected
                          ? colors.primary
                          : colors.onSurfaceVariant,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildTagsSelection(ColorScheme colors, TextTheme textTheme) {
    final List<String> availableTags = [
      'Work',
      'Family',
      'Health',
      'Sleep',
      'Exercise',
      'Social',
      'Creative',
      'Nature',
      'Calm',
      'Stressed',
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tags',
          style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: availableTags.map((tag) {
            final isSelected = _selectedTags.contains(tag);

            return FilterChip(
              label: Text(tag),
              selected: isSelected,
              onSelected: (selected) {
                setState(() {
                  if (selected) {
                    _selectedTags.add(tag);
                  } else {
                    _selectedTags.remove(tag);
                  }
                });
              },
              backgroundColor: colors.surfaceVariant,
              selectedColor: colors.primaryContainer,
              labelStyle: textTheme.bodyMedium?.copyWith(
                color: isSelected
                    ? colors.onPrimaryContainer
                    : colors.onSurface,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
              ),
              checkmarkColor: colors.onPrimaryContainer,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: BorderSide(
                  color: isSelected ? colors.primary : colors.outlineVariant,
                  width: 1,
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildNoteInput(ColorScheme colors, TextTheme textTheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Notes (Optional)',
          style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _noteController,
          maxLines: 4,
          decoration: InputDecoration(
            hintText: 'Add any thoughts or details...',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: colors.outlineVariant),
            ),
            filled: true,
            fillColor: colors.surface,
            contentPadding: const EdgeInsets.all(16),
            hintStyle: TextStyle(color: colors.onSurfaceVariant),
          ),
        ),
      ],
    );
  }
}

