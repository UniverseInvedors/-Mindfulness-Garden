// lib/features/brainwaves/binaural_beats_screen.dart
import 'package:flutter/material.dart';
import 'dart:async'; // For Timer
import 'package:just_audio/just_audio.dart';
import 'package:flutter_audio_capture/flutter_audio_capture.dart';
import 'dart:math';

class BinauralBeatsScreen extends StatefulWidget {
  const BinauralBeatsScreen({super.key});

  @override
  State<BinauralBeatsScreen> createState() => _BinauralBeatsScreenState();
}

class _BinauralBeatsScreenState extends State<BinauralBeatsScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  final FlutterAudioCapture _audioCapture = FlutterAudioCapture();

  BrainwaveState _currentState = BrainwaveState.focus;
  bool _isPlaying = false;
  double _baseFrequency = 200.0;
  double _beatFrequency = 10.0;
  double _volume = 0.7;
  List<double> _brainwaveData = [];
  Timer? _updateTimer;

  final Map<BrainwaveState, BrainwavePreset> _presets = {
    BrainwaveState.deepSleep: BrainwavePreset(
      name: 'Deep Sleep',
      baseFreq: 200.0,
      beatFreq: 2.0,
      color: Colors.purple,
      icon: Icons.bedtime,
      description: 'Delta waves for deep restorative sleep',
      duration: const Duration(minutes: 30),
    ),
    BrainwaveState.lightSleep: BrainwavePreset(
      name: 'Light Sleep',
      baseFreq: 200.0,
      beatFreq: 6.0,
      color: Colors.blue,
      icon: Icons.nightlight,
      description: 'Theta waves for relaxation and light sleep',
      duration: const Duration(minutes: 20),
    ),
    BrainwaveState.meditation: BrainwavePreset(
      name: 'Deep Meditation',
      baseFreq: 200.0,
      beatFreq: 8.0,
      color: Colors.green,
      icon: Icons.self_improvement,
      description: 'Alpha/Theta border for deep meditation',
      duration: const Duration(minutes: 25),
    ),
    BrainwaveState.focus: BrainwavePreset(
      name: 'Enhanced Focus',
      baseFreq: 200.0,
      beatFreq: 14.0,
      color: Colors.orange,
      icon: Icons.lightbulb,
      description: 'Beta waves for concentration and focus',
      duration: const Duration(minutes: 15),
    ),
    BrainwaveState.energy: BrainwavePreset(
      name: 'Energy Boost',
      baseFreq: 200.0,
      beatFreq: 18.0,
      color: Colors.yellow,
      icon: Icons.bolt,
      description: 'High Beta for energy and alertness',
      duration: const Duration(minutes: 10),
    ),
    BrainwaveState.creativity: BrainwavePreset(
      name: 'Creativity Flow',
      baseFreq: 200.0,
      beatFreq: 12.0,
      color: Colors.pink,
      icon: Icons.brush,
      description: 'Alpha waves for creative thinking',
      duration: const Duration(minutes: 20),
    ),
  };

  @override
  void initState() {
    super.initState();
    _setupAudio();
  }

  Future<void> _setupAudio() async {
    // Setup audio processing
    await _audioCapture.init();

    // Generate initial binaural beats
    await _generateBinauralBeats();
  }

  Future<void> _generateBinauralBeats() async {
    final preset = _presets[_currentState]!;
    _baseFrequency = preset.baseFreq;
    _beatFrequency = preset.beatFreq;

    // Generate sine waves for left and right channels
    // Left ear: base frequency
    // Right ear: base frequency + beat frequency
    // This creates the binaural beat effect

    // In a real implementation, you would generate audio buffers
    // and play them using a proper audio synthesis library

    // For now, we'll use pre-recorded audio files
    final audioFile = 'assets/binaural/${_currentState.name}.mp3';
    await _audioPlayer.setAsset(audioFile);
  }

  Future<void> _togglePlayback() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
      await _audioCapture.stop();
      _updateTimer?.cancel();
    } else {
      await _audioPlayer.play();
      await _audioCapture.start(
        (List<double> data) {
          _processAudioData(data);
        },
        (Object error) {
          debugPrint('Audio capture error: $error');
        },
      );

      // Start updating visualization
      _updateTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
        _updateVisualization();
      });
    }

    setState(() => _isPlaying = !_isPlaying);
  }

  void _processAudioData(List<double> data) {
    // Simple FFT simulation for brainwave analysis
    if (data.isNotEmpty) {
      final avg = data.reduce((a, b) => a + b) / data.length;
      _brainwaveData.add(avg);

      // Keep only last 100 data points
      if (_brainwaveData.length > 100) {
        _brainwaveData.removeAt(0);
      }
    }
  }

  void _updateVisualization() {
    setState(() {
      // Update visualization data
    });
  }

  void _changeState(BrainwaveState newState) {
    setState(() {
      _currentState = newState;
    });

    _generateBinauralBeats();

    if (_isPlaying) {
      _audioPlayer.seek(Duration.zero);
      _audioPlayer.play();
    }
  }

  void _adjustFrequency(double delta) {
    setState(() {
      _beatFrequency = (_beatFrequency + delta).clamp(0.5, 30.0);
    });

    if (_isPlaying) {
      _generateBinauralBeats();
      _audioPlayer.play();
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _audioCapture.stop();
    _updateTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final preset = _presets[_currentState]!;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Binaural Beats'),
        actions: [
          IconButton(
            onPressed: () => _showInfo(),
            icon: const Icon(Icons.info),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0a0a0a), Color(0xFF1a1a2e)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // Brainwave Visualization
                Expanded(child: Center(child: _buildBrainwaveVisualization())),

                // Current State Info
                _buildStateInfo(preset),

                const SizedBox(height: 30),

                // Frequency Controls
                _buildFrequencyControls(),

                const SizedBox(height: 30),

                // State Selection
                _buildStateSelection(),

                const SizedBox(height: 20),

                // Playback Controls
                _buildPlaybackControls(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBrainwaveVisualization() {
    return CustomPaint(
      size: const Size(double.infinity, 200),
      painter: BrainwavePainter(
        brainwaveData: _brainwaveData,
        beatFrequency: _beatFrequency,
        isPlaying: _isPlaying,
        color: _presets[_currentState]!.color,
      ),
    );
  }

  Widget _buildStateInfo(BrainwavePreset preset) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: preset.color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: preset.color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(preset.icon, color: preset.color, size: 30),
              const SizedBox(width: 10),
              Text(
                preset.name,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: preset.color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            preset.description,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.white.withOpacity(0.8),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildInfoItem(
                'Frequency',
                '${_beatFrequency.toStringAsFixed(1)} Hz',
              ),
              const SizedBox(width: 20),
              _buildInfoItem('Duration', '${preset.duration.inMinutes} min'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(0.6)),
        ),
        const SizedBox(height: 5),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildFrequencyControls() {
    return Column(
      children: [
        const Text(
          'Beat Frequency',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              onPressed: () => _adjustFrequency(-0.5),
              icon: const Icon(Icons.remove, color: Colors.white),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(
                '${_beatFrequency.toStringAsFixed(1)} Hz',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
            IconButton(
              onPressed: () => _adjustFrequency(0.5),
              icon: const Icon(Icons.add, color: Colors.white),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Slider(
          value: _beatFrequency,
          min: 0.5,
          max: 30.0,
          onChanged: (value) {
            _adjustFrequency(value - _beatFrequency);
          },
          activeColor: _presets[_currentState]!.color,
          inactiveColor: Colors.white.withOpacity(0.3),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: const [
            Text('Delta', style: TextStyle(color: Colors.white70)),
            Text('Theta', style: TextStyle(color: Colors.white70)),
            Text('Alpha', style: TextStyle(color: Colors.white70)),
            Text('Beta', style: TextStyle(color: Colors.white70)),
            Text('Gamma', style: TextStyle(color: Colors.white70)),
          ],
        ),
      ],
    );
  }

  Widget _buildStateSelection() {
    return SizedBox(
      height: 100,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: BrainwaveState.values.map((state) {
          final preset = _presets[state]!;
          final isSelected = _currentState == state;

          return GestureDetector(
            onTap: () => _changeState(state),
            child: Container(
              width: 100,
              margin: const EdgeInsets.only(right: 10),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isSelected
                    ? preset.color.withOpacity(0.3)
                    : Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(
                  color: isSelected ? preset.color : Colors.transparent,
                  width: isSelected ? 2 : 0,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(preset.icon, color: preset.color),
                  const SizedBox(height: 5),
                  Text(
                    preset.name.split(' ').first,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight:
                          isSelected ? FontWeight.w700 : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildPlaybackControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.skip_previous, color: Colors.white, size: 30),
        ),
        GestureDetector(
          onTap: _togglePlayback,
          child: Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  _presets[_currentState]!.color,
                  _presets[_currentState]!.color.withOpacity(0.7),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: _presets[_currentState]!.color.withOpacity(0.5),
                  blurRadius: 20,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Icon(
              _isPlaying ? Icons.pause : Icons.play_arrow,
              size: 40,
              color: Colors.white,
            ),
          ),
        ),
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.skip_next, color: Colors.white, size: 30),
        ),
      ],
    );
  }

  void _showInfo() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        title: const Text(
          'Binaural Beats',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Binaural beats use two slightly different frequencies played in each ear. '
          'Your brain perceives a third frequency equal to the difference, which can '
          'entrain your brainwaves to specific states like relaxation, focus, or sleep.\n\n'
          'Wear headphones for best results.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}

class BrainwavePainter extends CustomPainter {
  final List<double> brainwaveData;
  final double beatFrequency;
  final bool isPlaying;
  final Color color;

  BrainwavePainter({
    required this.brainwaveData,
    required this.beatFrequency,
    required this.isPlaying,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);

    // Draw background circles
    final backgroundPaint = Paint()
      ..color = Colors.white.withOpacity(0.05)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    for (int i = 1; i <= 5; i++) {
      final radius = size.width * 0.4 * (i / 5);
      canvas.drawCircle(center, radius, backgroundPaint);
    }

    // Draw brainwave if data exists
    if (brainwaveData.isNotEmpty) {
      final wavePaint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round;

      final path = Path();
      final pointCount = brainwaveData.length;
      final step = size.width / (pointCount - 1);

      for (int i = 0; i < pointCount; i++) {
        final x = i * step;
        final y = center.dy + brainwaveData[i] * 50;

        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }

      canvas.drawPath(path, wavePaint);
    }

    // Draw rotating frequency indicator
    if (isPlaying) {
      final indicatorPaint = Paint()
        ..color = color.withOpacity(0.8)
        ..style = PaintingStyle.fill;

      final angle =
          DateTime.now().millisecond / 1000 * 2 * pi * (beatFrequency / 10);
      final indicatorRadius = size.width * 0.35;
      final indicatorX = center.dx + cos(angle) * indicatorRadius;
      final indicatorY = center.dy + sin(angle) * indicatorRadius;

      canvas.drawCircle(Offset(indicatorX, indicatorY), 8, indicatorPaint);
    }

    // Draw center frequency text
    final textStyle = TextStyle(
      color: color,
      fontSize: 24,
      fontWeight: FontWeight.w700,
    );

    final textSpan = TextSpan(
      text: '${beatFrequency.toStringAsFixed(1)} Hz',
      style: textStyle,
    );

    final textPainter = TextPainter(
      text: textSpan,
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    );

    textPainter.layout();
    textPainter.paint(
      canvas,
      Offset(
        center.dx - textPainter.width / 2,
        center.dy - textPainter.height / 2,
      ),
    );
  }

  @override
  bool shouldRepaint(covariant BrainwavePainter oldDelegate) {
    return brainwaveData != oldDelegate.brainwaveData ||
        beatFrequency != oldDelegate.beatFrequency ||
        isPlaying != oldDelegate.isPlaying ||
        color != oldDelegate.color;
  }
}

enum BrainwaveState {
  deepSleep,
  lightSleep,
  meditation,
  focus,
  energy,
  creativity,
}

class BrainwavePreset {
  final String name;
  final double baseFreq;
  final double beatFreq;
  final Color color;
  final IconData icon;
  final String description;
  final Duration duration;

  BrainwavePreset({
    required this.name,
    required this.baseFreq,
    required this.beatFreq,
    required this.color,
    required this.icon,
    required this.description,
    required this.duration,
  });
}

