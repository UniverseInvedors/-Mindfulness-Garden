// lib/features/music/meditation_music_screen.dart
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:mindfulness_garden/core/services/audio_service.dart';
import 'package:mindfulness_garden/data/models/music_track_model.dart';

class MeditationMusicScreen extends StatefulWidget {
  const MeditationMusicScreen({super.key});

  @override
  State<MeditationMusicScreen> createState() => _MeditationMusicScreenState();
}

class _MeditationMusicScreenState extends State<MeditationMusicScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  final AudioService _audioService = AudioService();

  List<MusicTrack> _tracks = [];
  int? _currentTrackIndex;
  bool _isPlaying = false;
  double _volume = 0.7;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  @override
  void initState() {
    super.initState();
    _loadTracks();
    _setupAudio();
  }

  void _loadTracks() {
    _tracks = [
      MusicTrack(
        id: '1',
        title: 'Morning Meditation',
        artist: 'Zen Garden',
        duration: const Duration(minutes: 15),
        category: 'Focus',
        color: Colors.orange,
        asset: 'assets/music/morning_meditation.mp3',
      ),
      MusicTrack(
        id: '2',
        title: 'Deep Sleep',
        artist: 'Sleep Waves',
        duration: const Duration(minutes: 30),
        category: 'Sleep',
        color: Colors.blue,
        asset: 'assets/music/deep_sleep.mp3',
      ),
      MusicTrack(
        id: '3',
        title: 'Stress Relief',
        artist: 'Calm Mind',
        duration: const Duration(minutes: 20),
        category: 'Relaxation',
        color: Colors.green,
        asset: 'assets/music/stress_relief.mp3',
      ),
      MusicTrack(
        id: '4',
        title: 'Energy Boost',
        artist: 'Vitality Sounds',
        duration: const Duration(minutes: 10),
        category: 'Energy',
        color: Colors.yellow,
        asset: 'assets/music/energy_boost.mp3',
      ),
    ];
  }

  Future<void> _setupAudio() async {
    _audioPlayer.positionStream.listen((position) {
      setState(() => _position = position);
    });

    _audioPlayer.durationStream.listen((duration) {
      setState(() => _duration = duration ?? Duration.zero);
    });

    _audioPlayer.playerStateStream.listen((state) {
      setState(() {
        _isPlaying = state.playing;
      });
    });
  }

  Future<void> _playTrack(MusicTrack track) async {
    try {
      await _audioPlayer.setAsset(track.asset);
      await _audioPlayer.play();
      setState(() {
        _currentTrackIndex = _tracks.indexOf(track);
      });
    } catch (e) {
      print('Error playing track: $e');
    }
  }

  Future<void> _pauseTrack() async {
    await _audioPlayer.pause();
  }

  Future<void> _resumeTrack() async {
    await _audioPlayer.play();
  }

  Future<void> _stopTrack() async {
    await _audioPlayer.stop();
    setState(() {
      _isPlaying = false;
      _position = Duration.zero;
    });
  }

  void _seekTo(Duration position) {
    _audioPlayer.seek(position);
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  void _showCategories() {
    final categories = _tracks.map((track) => track.category).toSet().toList();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(25),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  'Categories',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                ),
              ),
              ...categories.map((category) {
                final categoryTracks = _tracks
                    .where((track) => track.category == category)
                    .toList();
                return ListTile(
                  leading: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: categoryTracks.first.color.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.music_note,
                      color: categoryTracks.first.color,
                    ),
                  ),
                  title: Text(category),
                  subtitle: Text('${categoryTracks.length} tracks'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.of(context).pop();
                    // You could filter tracks by category here
                  },
                );
              }).toList(),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meditation Music'),
        actions: [
          IconButton(
            onPressed: () => _showCategories(),
            icon: const Icon(Icons.category),
          ),
        ],
      ),
      body: Column(
        children: [
          // Now Playing
          if (_currentTrackIndex != null)
            _buildNowPlaying(_tracks[_currentTrackIndex!]),

          // Music Library
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                childAspectRatio: 0.8,
              ),
              itemCount: _tracks.length,
              itemBuilder: (context, index) {
                final track = _tracks[index];
                return _buildMusicCard(track, index);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNowPlaying(MusicTrack track) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [track.color.withOpacity(0.9), track.color.withOpacity(0.7)],
        ),
      ),
      child: Column(
        children: [
          // Track Info
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const Icon(
                  Icons.music_note,
                  color: Colors.white,
                  size: 30,
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      track.title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      track.artist,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Progress Bar
          Column(
            children: [
              Slider(
                value: _position.inSeconds.toDouble(),
                min: 0,
                max: _duration.inSeconds.toDouble(),
                onChanged: (value) {
                  _seekTo(Duration(seconds: value.toInt()));
                },
                activeColor: Colors.white,
                inactiveColor: Colors.white.withOpacity(0.3),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _formatDuration(_position),
                    style: const TextStyle(fontSize: 12, color: Colors.white70),
                  ),
                  Text(
                    _formatDuration(_duration),
                    style: const TextStyle(fontSize: 12, color: Colors.white70),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Controls
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.skip_previous,
                  color: Colors.white,
                  size: 30,
                ),
              ),
              IconButton(
                onPressed: _isPlaying ? _pauseTrack : _resumeTrack,
                icon: Icon(
                  _isPlaying
                      ? Icons.pause_circle_filled
                      : Icons.play_circle_filled,
                  color: Colors.white,
                  size: 50,
                ),
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.skip_next,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMusicCard(MusicTrack track, int index) {
    final isPlaying = _currentTrackIndex == index && _isPlaying;

    return GestureDetector(
      onTap: () => _playTrack(track),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isPlaying
                ? [track.color, track.color.withOpacity(0.7)]
                : [
                    Colors.white.withOpacity(0.1),
                    Colors.white.withOpacity(0.05),
                  ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isPlaying
                ? track.color.withOpacity(0.5)
                : Colors.white.withOpacity(0.2),
            width: isPlaying ? 2 : 1,
          ),
        ),
        child: Stack(
          children: [
            // Background Pattern
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: CustomPaint(
                  painter: MusicWavePainter(
                    color: track.color.withOpacity(0.1),
                    isPlaying: isPlaying,
                  ),
                ),
              ),
            ),

            // Content
            Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Icon(
                      Icons.music_note,
                      color: Colors.white,
                      size: 25,
                    ),
                  ),
                  const SizedBox(height: 15),
                  Text(
                    track.title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  Text(
                    track.artist,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white.withOpacity(0.7),
                    ),
                  ),
                  const Spacer(),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: track.color.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          track.category,
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const Spacer(),
                      Text(
                        _formatDuration(track.duration),
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white.withOpacity(0.7),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Play Indicator
            if (isPlaying)
              Positioned(
                top: 10,
                right: 10,
                child: Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.play_arrow,
                    color: Colors.white,
                    size: 12,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return "$minutes:$seconds";
  }
}

// Add this class at the bottom of meditation_music_screen.dart
class MusicWavePainter extends CustomPainter {
  final Color color;
  final bool isPlaying;

  MusicWavePainter({
    required this.color,
    this.isPlaying = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final waveCount = 8;
    final waveHeight = size.height * 0.15;
    final waveWidth = size.width / waveCount;

    for (int i = 0; i < waveCount; i++) {
      final x = waveWidth * i + waveWidth / 2;
      final amplitude = isPlaying
          ? waveHeight * (0.5 + 0.5 * ((i % 3) / 3))
          : waveHeight * (0.3 + 0.2 * ((i % 3) / 3));
      final y = size.height / 2;

      final path = Path()
        ..moveTo(x, y)
        ..quadraticBezierTo(
          x + waveWidth / 4,
          y - amplitude,
          x + waveWidth / 2,
          y,
        )
        ..quadraticBezierTo(
          x + waveWidth * 3 / 4,
          y + amplitude,
          x + waveWidth,
          y,
        );

      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant MusicWavePainter oldDelegate) {
    return color != oldDelegate.color || isPlaying != oldDelegate.isPlaying;
  }
}

