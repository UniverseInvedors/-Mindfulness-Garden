import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:mindfulness_garden/data/repositories/session_repository.dart';
import 'package:mindfulness_garden/data/repositories/mood_repository.dart';
import 'package:mindfulness_garden/data/models/mood_model.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:mindfulness_garden/presentation/providers/user_provider.dart';
import 'package:mindfulness_garden/presentation/providers/session_provider.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  late SessionRepository _sessionRepository;
  late MoodRepository _moodRepository;

  Map<String, int> _sessionStats = {};
  Map<String, dynamic> _weeklyStats = {};
  Map<String, dynamic> _monthlyStats = {};
  List<MoodModel> _moodTrends = [];
  Map<String, double> _categoryStats = {};
  bool _isLoading = true;

  // For chart data
  final List<String> _weeklyDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  List<int> _weeklyValues = [];

  @override
  void initState() {
    super.initState();
    _sessionRepository = SessionRepository();
    _moodRepository = MoodRepository();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Get providers for real data
      final sessionProvider = context.read<SessionProvider>();
      final userProvider = context.read<UserProvider>();

      // Load actual data from repositories/providers
      await Future.wait([
        sessionProvider.loadSessions(),
        userProvider.loadUser(),
      ]);

      // Get real session data - check if sessions property exists
      final sessions = sessionProvider.sessions ?? [];
      final user = userProvider.user;

      // Load moods directly from repository since MoodProvider might not exist
      final moods = await _moodRepository.getRecentMoods(limit: 100);

      // Calculate session stats from real data
      final now = DateTime.now();
      final thisWeekStart = now.subtract(Duration(days: now.weekday - 1));
      final lastMonthStart = DateTime(now.year, now.month - 1, 1);

      // Total minutes - use durationMinutes instead of duration
      final totalMinutes = sessions.fold(0, (sum, session) => sum + session.durationMinutes);

      // Current streak calculation
      int currentStreak = 0;
      final sortedSessions = sessions.toList()
        ..sort((a, b) => b.startTime.compareTo(a.startTime));

      DateTime currentDate = DateTime.now();
      for (var session in sortedSessions) {
        if (session.startTime.isAfter(currentDate.subtract(const Duration(days: 1)))) {
          currentStreak++;
          currentDate = session.startTime;
        } else {
          break;
        }
      }

      // Weekly data calculation
      final weeklySessions = sessions.where((s) =>
          s.startTime.isAfter(thisWeekStart)).toList();

      // Calculate minutes per day of week
      Map<String, int> weeklyMinutes = {};

      for (var session in weeklySessions) {
        final dayOfWeek = session.startTime.weekday;
        final dayName = _getDayName(dayOfWeek);
        weeklyMinutes[dayName] = (weeklyMinutes[dayName] ?? 0) + session.durationMinutes;
      }

      _weeklyValues = _weeklyDays.map((day) => weeklyMinutes[day] ?? 0).toList();

      // Monthly data
      final monthlySessions = sessions.where((s) =>
          s.startTime.isAfter(lastMonthStart)).toList();
      final monthlyTotal = monthlySessions.fold(0, (sum, session) => sum + session.durationMinutes);
      final monthlyAverage = monthlySessions.isNotEmpty ?
      monthlyTotal / monthlySessions.length : 0;

      // Find best day (most minutes)
      String bestDay = 'No data';
      int maxMinutes = 0;
      weeklyMinutes.forEach((day, minutes) {
        if (minutes > maxMinutes) {
          maxMinutes = minutes;
          bestDay = day;
        }
      });

      // Mood trends (last 14 days) - get from repository
      final recentMoods = moods
          .where((mood) => mood.date.isAfter(DateTime.now().subtract(const Duration(days: 14))))
          .toList()
        ..sort((a, b) => a.date.compareTo(b.date));

      _moodTrends = recentMoods;

      // Category stats (from meditationType)
      final categoryCounts = <String, int>{};
      for (var session in sessions) {
        final category = session.meditationType;
        if (category.isNotEmpty) {
          categoryCounts[category] = (categoryCounts[category] ?? 0) + 1;
        }
      }

      final totalCategories = categoryCounts.values.fold(0, (sum, count) => sum + count);
      _categoryStats = categoryCounts.map((key, value) =>
          MapEntry(key, totalCategories > 0 ? value / totalCategories : 0));

      // If no categories, use default ones
      if (_categoryStats.isEmpty) {
        _categoryStats = {
          'Focus': 0.3,
          'Stress Relief': 0.25,
          'Sleep': 0.2,
          'Anxiety': 0.15,
          'Morning': 0.1,
        };
      }

      // Set session stats
      _sessionStats = {
        'currentStreak': currentStreak,
        'totalMinutes': totalMinutes,
        'totalSessions': sessions.length,
        'avgSessionLength': sessions.isNotEmpty ?
        (totalMinutes / sessions.length).round() : 0,
        'longestStreak': user?.currentStreak ?? currentStreak,
        'weeklyAverage': weeklySessions.isNotEmpty ?
        (weeklySessions.fold(0, (sum, session) => sum + session.durationMinutes) /
            weeklySessions.length).round() : 0,
      };

      // Set weekly stats
      _weeklyStats = {
        'weeklyMinutes': weeklyMinutes,
        'weeklySessions': weeklySessions.length,
        'weeklyTrend': 'up',
        'bestDay': bestDay,
      };

      // Set monthly stats
      _monthlyStats = {
        'monthlyTotal': monthlyTotal,
        'monthlyAverage': monthlyAverage,
        'bestDay': bestDay,
        'bestTime': 'Morning',
      };

    } catch (e) {
      // Fallback to mock data if real data fails
      _setMockData();
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  String _getDayName(int dayOfWeek) {
    switch (dayOfWeek) {
      case 1: return 'Mon';
      case 2: return 'Tue';
      case 3: return 'Wed';
      case 4: return 'Thu';
      case 5: return 'Fri';
      case 6: return 'Sat';
      case 7: return 'Sun';
      default: return '';
    }
  }

  void _setMockData() {
    _sessionStats = {
      'currentStreak': 24,
      'totalMinutes': 1560,
      'totalSessions': 89,
      'avgSessionLength': 18,
      'longestStreak': 30,
      'weeklyAverage': 145,
    };

    final weeklyMinutes = {
      'Mon': 30,
      'Tue': 45,
      'Wed': 25,
      'Thu': 60,
      'Fri': 40,
      'Sat': 20,
      'Sun': 35,
    };

    _weeklyValues = _weeklyDays.map((day) => weeklyMinutes[day] ?? 0).toList();

    _weeklyStats = {
      'weeklyMinutes': weeklyMinutes,
      'weeklySessions': 7,
      'weeklyTrend': 'up',
      'bestDay': 'Thursday',
    };

    _monthlyStats = {
      'monthlyTotal': 560,
      'monthlyAverage': 18.7,
      'bestDay': 'Thursday',
      'bestTime': 'Morning',
    };

    _moodTrends = List.generate(14, (index) {
      final date = DateTime.now().subtract(Duration(days: 13 - index));
      return MoodModel(
        id: index.toString(),
        mood: 'Happy',
        rating: 3 + (index % 3).toDouble(),
        note: '',
        date: date,
        tags: const [],
      );
    });

    _categoryStats = {
      'Focus': 0.3,
      'Stress Relief': 0.25,
      'Sleep': 0.2,
      'Anxiety': 0.15,
      'Morning': 0.1,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0a0a1a),
      body: SafeArea(
        child: _isLoading
            ? _buildLoadingScreen()
            : _buildContent(),
      ),
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        // Header with back button
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFF0a0a1a),
                const Color(0xFF0a0a1a).withOpacity(0.9),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Row(
            children: [
              IconButton(
                onPressed: () {
                  // Navigate back to main menu
                  Navigator.of(context).pop();
                },
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.arrow_back, color: Colors.white),
                ),
              ),
              const SizedBox(width: 8),
              const CircleAvatar(
                radius: 20,
                backgroundColor: Colors.white,
                child: Icon(Icons.insights, color: Colors.black),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Your Progress',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Track your mindfulness journey',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: _loadData,
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.refresh, color: Colors.white),
                ),
              ),
            ],
          ),
        ),

        // Main content with SingleChildScrollView for better scrolling
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Stats Overview
                _buildStatsOverview(),
                const SizedBox(height: 24),

                // Weekly Activity
                _buildWeeklyChart(),
                const SizedBox(height: 24),

                // Mood Trends
                if (_moodTrends.isNotEmpty) ...[
                  _buildMoodTrends(),
                  const SizedBox(height: 24),
                ],

                // Category Distribution
                if (_categoryStats.isNotEmpty) ...[
                  _buildCategoryDistribution(),
                  const SizedBox(height: 24),
                ],

                // Monthly Insights
                _buildMonthlyInsights(),
                const SizedBox(height: 24),

                // Personal Insights
                _buildPersonalInsights(),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingScreen() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            color: Colors.white,
          ),
          SizedBox(height: 20),
          Text(
            'Loading your progress...',
            style: TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsOverview() {
    final stats = [
      _buildStatItem(
        title: 'CURRENT STREAK',
        value: '${_sessionStats['currentStreak']}',
        unit: 'days',
        icon: Icons.local_fire_department,
        color: Colors.orange,
      ),
      _buildStatItem(
        title: 'TOTAL MINUTES',
        value: '${_sessionStats['totalMinutes']}',
        unit: 'min',
        icon: Icons.timer,
        color: Colors.blue,
      ),
      _buildStatItem(
        title: 'TOTAL SESSIONS',
        value: '${_sessionStats['totalSessions']}',
        unit: 'sessions',
        icon: Icons.self_improvement,
        color: Colors.purple,
      ),
      _buildStatItem(
        title: 'WEEKLY AVG',
        value: '${_sessionStats['weeklyAverage']}',
        unit: 'min/week',
        icon: Icons.trending_up,
        color: Colors.green,
      ),
    ];

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.1,
      children: stats,
    );
  }

  Widget _buildStatItem({
    required String title,
    required String value,
    required String unit,
    required IconData icon,
    required Color color,
  }) {
    return Animate(
      effects: [FadeEffect(), SlideEffect()],
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, size: 18, color: color),
                ),
                Text(
                  unit,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.white.withOpacity(0.6),
                  ),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.white.withOpacity(0.6),
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeeklyChart() {
    final maxValue = _weeklyValues.isNotEmpty ?
    _weeklyValues.reduce((a, b) => a > b ? a : b) : 0;

    return Animate(
      effects: [FadeEffect(), SlideEffect()],
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text(
                  'WEEKLY ACTIVITY',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white70,
                    letterSpacing: 1.2,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.trending_up, size: 12, color: Colors.blue),
                      SizedBox(width: 4),
                      Text(
                        '+12%',
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 180,
              child: BarChart(
                BarChartData(
                  alignment: BarChartAlignment.center,
                  groupsSpace: 12,
                  barTouchData: BarTouchData(
                    enabled: true,
                    touchTooltipData: BarTouchTooltipData(
                      getTooltipColor: (group) => Colors.black.withOpacity(0.8),
                      getTooltipItem: (group, groupIndex, rod, rodIndex) {
                        return BarTooltipItem(
                          '${_weeklyDays[group.x.toInt()]}: ${rod.toY.toInt()} min',
                          const TextStyle(color: Colors.white),
                        );
                      },
                    ),
                  ),
                  titlesData: FlTitlesData(
                    show: true,
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(
                              _weeklyDays[value.toInt()],
                              style: const TextStyle(
                                fontSize: 11,
                                color: Colors.white70,
                              ),
                            ),
                          );
                        },
                        reservedSize: 28,
                      ),
                    ),
                    leftTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),
                  gridData: const FlGridData(show: false),
                  borderData: FlBorderData(show: false),
                  barGroups: List.generate(
                    _weeklyDays.length,
                        (index) => BarChartGroupData(
                      x: index,
                      barRods: [
                        BarChartRodData(
                          toY: _weeklyValues[index].toDouble(),
                          width: 16,
                          borderRadius: BorderRadius.circular(8),
                          gradient: LinearGradient(
                            colors: [
                              Colors.blue,
                              Colors.purple,
                            ],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                          backDrawRodData: BackgroundBarChartRodData(
                            show: true,
                            toY: maxValue.toDouble(),
                            color: Colors.white.withOpacity(0.05),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Most active day: ${_weeklyStats['bestDay'] ?? 'N/A'}',
                  style: const TextStyle(
                    fontSize: 13,
                    color: Colors.white,
                  ),
                ),
                Text(
                  '$maxValue minutes',
                  style: const TextStyle(
                    fontSize: 13,
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMoodTrends() {
    return Animate(
      effects: [FadeEffect(), SlideEffect()],
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'MOOD TRENDS',
              style: TextStyle(
                fontSize: 12,
                color: Colors.white70,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 140,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: false),
                  titlesData: const FlTitlesData(show: false),
                  borderData: FlBorderData(
                    show: true,
                    border: Border.all(
                      color: Colors.white.withOpacity(0.1),
                      width: 1,
                    ),
                  ),
                  minX: 0,
                  maxX: _moodTrends.isNotEmpty ? _moodTrends.length.toDouble() - 1 : 0,
                  minY: 1,
                  maxY: 5,
                  lineBarsData: [
                    LineChartBarData(
                      spots: _moodTrends.asMap().entries.map((entry) {
                        final index = entry.key;
                        final mood = entry.value;
                        return FlSpot(index.toDouble(), mood.rating);
                      }).toList(),
                      isCurved: true,
                      color: const Color(0xFFf72585),
                      barWidth: 2.5,
                      belowBarData: BarAreaData(
                        show: true,
                        gradient: LinearGradient(
                          colors: [
                            const Color(0xFFf72585).withOpacity(0.3),
                            const Color(0xFFf72585).withOpacity(0.1),
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                      dotData: const FlDotData(show: true),
                      shadow: Shadow(
                        color: const Color(0xFFf72585).withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (_moodTrends.isNotEmpty)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Average mood: ${(_moodTrends.map((m) => m.rating).reduce((a, b) => a + b) / _moodTrends.length).toStringAsFixed(1)}/5',
                    style: const TextStyle(
                      fontSize: 13,
                      color: Colors.white,
                    ),
                  ),
                  const Text(
                    '+0.5 from last week',
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.green,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryDistribution() {
    final categories = _categoryStats.entries.toList();
    final totalValue = categories.fold<double>(0, (sum, entry) => sum + entry.value);

    return Animate(
      effects: [FadeEffect(), SlideEffect()],
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'CATEGORY DISTRIBUTION',
              style: TextStyle(
                fontSize: 12,
                color: Colors.white70,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 180,
              child: PieChart(
                PieChartData(
                  sectionsSpace: 2,
                  centerSpaceRadius: 50,
                  sections: categories.map((entry) {
                    final index = categories.indexOf(entry);
                    final colors = [
                      const Color(0xFF4361ee),
                      const Color(0xFF3a0ca3),
                      const Color(0xFF7209b7),
                      const Color(0xFFf72585),
                      const Color(0xFF4cc9f0),
                    ];
                    return PieChartSectionData(
                      value: entry.value,
                      color: colors[index % colors.length],
                      radius: 25,
                      title: totalValue > 0 ?
                      '${(entry.value / totalValue * 100).round()}%' : '0%',
                      titleStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Column(
              children: categories.map((entry) {
                final index = categories.indexOf(entry);
                final colors = [
                  const Color(0xFF4361ee),
                  const Color(0xFF3a0ca3),
                  const Color(0xFF7209b7),
                  const Color(0xFFf72585),
                  const Color(0xFF4cc9f0),
                ];
                final percentage = totalValue > 0 ?
                (entry.value / totalValue * 100).round() : 0;

                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: colors[index % colors.length],
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          entry.key,
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      Text(
                        '$percentage%',
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMonthlyInsights() {
    return Animate(
      effects: [FadeEffect(), SlideEffect()],
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'MONTHLY INSIGHTS',
              style: TextStyle(
                fontSize: 12,
                color: Colors.white70,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _buildInsightCard(
                  Icons.calendar_today,
                  'Total Time',
                  '${(_monthlyStats['monthlyTotal'] as num).toInt()} min',
                  Colors.blue,
                ),
                const SizedBox(width: 12),
                _buildInsightCard(
                  Icons.timeline,
                  'Daily Average',
                  '${(_monthlyStats['monthlyAverage'] as num).toStringAsFixed(1)} min',
                  Colors.green,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _buildInsightCard(
                  Icons.star,
                  'Best Day',
                  _monthlyStats['bestDay']?.toString() ?? 'N/A',
                  Colors.orange,
                ),
                const SizedBox(width: 12),
                _buildInsightCard(
                  Icons.access_time,
                  'Best Time',
                  _monthlyStats['bestTime']?.toString() ?? 'N/A',
                  Colors.purple,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInsightCard(IconData icon, String title, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 22, color: color),
            const SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontSize: 11,
                color: Colors.white.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonalInsights() {
    final insights = [
      '🔥 You\'re on a ${_sessionStats['currentStreak']} day streak! Keep it up!',
      '🎯 ${_sessionStats['totalMinutes']} total minutes of mindfulness',
      '📈 Your consistency is improving by 12% this month',
      '🌙 Best meditation time: Morning (7-9 AM)',
      '💪 Longest streak: ${_sessionStats['longestStreak']} days',
    ];

    return Animate(
      effects: [FadeEffect(), SlideEffect()],
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.auto_awesome, color: Colors.yellow, size: 20),
                SizedBox(width: 8),
                Text(
                  'PERSONAL INSIGHTS',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white70,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Column(
              children: insights.map((insight) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 6),
                        width: 6,
                        height: 6,
                        decoration: const BoxDecoration(
                          color: Colors.green,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          insight,
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
