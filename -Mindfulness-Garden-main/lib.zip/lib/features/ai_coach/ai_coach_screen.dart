// lib/features/ai_coach/ai_coach_screen.dart
import 'package:flutter/material.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:camera/camera.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:mindfulness_garden/core/services/ai_service.dart';

class AiCoachScreen extends StatefulWidget {
  const AiCoachScreen({super.key});

  @override
  State<AiCoachScreen> createState() => _AiCoachScreenState();
}

class _AiCoachScreenState extends State<AiCoachScreen> {
  final AiService _aiService = AiService();
  final stt.SpeechToText _speechToText = stt.SpeechToText();
  CameraController? _cameraController;
  bool _isListening = false;
  bool _isAnalyzing = false;
  String _aiResponse = '';
  List<EmotionData> _emotionHistory = [];
  MeditationRecommendation? _currentRecommendation;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _initializeSpeech();
    _loadUserProfile();
  }

  Future<void> _initializeCamera() async {
    final cameras = await availableCameras();
    if (cameras.isNotEmpty) {
      _cameraController = CameraController(
        cameras.first,
        ResolutionPreset.medium,
      );
      await _cameraController!.initialize();
      setState(() {});
    }
    return;
  }

  Future<void> _initializeSpeech() async {
    await _speechToText.initialize();
  }

  Future<void> _loadUserProfile() async {
    // Load user meditation history, preferences, and goals
    final profile = await _aiService.getUserProfile();
    _generateInitialRecommendation(profile);
  }

  void _generateInitialRecommendation(UserProfile profile) {
    final now = DateTime.now();

    if (profile.lastMeditationTime != null &&
        now.difference(profile.lastMeditationTime!).inHours < 2) {
      // User meditated recently
      _currentRecommendation = MeditationRecommendation(
        type: MeditationType.gratitude,
        duration: const Duration(minutes: 5),
        reason: 'Build on your recent meditation momentum',
        confidence: 0.8,
      );
    } else if (now.hour >= 21 || now.hour <= 6) {
      // Evening/Night time
      _currentRecommendation = MeditationRecommendation(
        type: MeditationType.sleep,
        duration: const Duration(minutes: 10),
        reason: 'Prepare for restful sleep',
        confidence: 0.9,
      );
    } else if (profile.stressLevel > 70) {
      // High stress
      _currentRecommendation = MeditationRecommendation(
        type: MeditationType.stressRelief,
        duration: const Duration(minutes: 15),
        reason: 'Your stress levels are elevated',
        confidence: 0.85,
      );
    } else {
      // Default recommendation
      _currentRecommendation = MeditationRecommendation(
        type: MeditationType.breathAwareness,
        duration: const Duration(minutes: 10),
        reason: 'Daily mindfulness practice',
        confidence: 0.7,
      );
    }

    setState(() {});
  }

  Future<void> _analyzeEmotion() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      return;
    }

    setState(() => _isAnalyzing = true);

    try {
      final image = await _cameraController!.takePicture();
      final emotion = await _aiService.analyzeEmotion(image.path);

      _emotionHistory.add(
        EmotionData(
          emotion: emotion,
          timestamp: DateTime.now(),
          confidence: emotion.confidence,
        ),
      );

      // Keep only last 10 emotions
      if (_emotionHistory.length > 10) {
        _emotionHistory.removeAt(0);
      }

      // Update recommendation based on emotion
      await _updateRecommendationBasedOnEmotion(emotion);
    } catch (e) {
      print('Error analyzing emotion: $e');
    } finally {
      setState(() => _isAnalyzing = false);
    }

    return;
  }

  Future<void> _updateRecommendationBasedOnEmotion(Emotion emotion) async {
    MeditationType recommendedType;
    String reason;
    double confidence;

    switch (emotion.type) {
      case EmotionType.angry:
        recommendedType = MeditationType.lovingKindness;
        reason =
            'I notice some tension. Loving-kindness meditation can help cultivate compassion';
        confidence = 0.9;
        break;
      case EmotionType.sad:
        recommendedType = MeditationType.gratitude;
        reason =
            'A gratitude practice can help shift perspective and find positivity';
        confidence = 0.85;
        break;
      case EmotionType.stressed:
        recommendedType = MeditationType.bodyScan;
        reason = 'Body scan meditation can help release physical tension';
        confidence = 0.8;
        break;
      case EmotionType.tired:
        recommendedType = MeditationType.energyBoost;
        reason = 'An energizing meditation can help revitalize you';
        confidence = 0.75;
        break;
      default:
        recommendedType = MeditationType.breathAwareness;
        reason = 'Continue with mindful breathing for general well-being';
        confidence = 0.7;
    }

    _currentRecommendation = MeditationRecommendation(
      type: recommendedType,
      duration: const Duration(minutes: 10),
      reason: reason,
      confidence: confidence,
    );

    setState(() {});

    return; // ✅ ensures Future<void> completes properly
  }

  Future<void> _startListening() async {
    if (!_isListening) {
      setState(() => _isListening = true);

      await _speechToText.listen(
        onResult: (result) {
          if (result.finalResult) {
            _processUserSpeech(result.recognizedWords);
          }
        },
        listenFor: const Duration(seconds: 30),
      );
    }
  }

  Future<void> _processUserSpeech(String speech) async {
    // Analyze speech sentiment and content
    final analysis = await _aiService.analyzeSpeech(speech);

    // Generate AI response
    final response = await _aiService.generateResponse(
      userInput: speech,
      context: analysis,
      emotionHistory: _emotionHistory,
    );

    setState(() {
      _aiResponse = response;
    });

    // Speak the response
    await _aiService.speakResponse(response);
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _speechToText.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Meditation Coach'),
        actions: [
          IconButton(
            onPressed: _analyzeEmotion,
            icon: Icon(
              _isAnalyzing ? Icons.psychology : Icons.face,
              color: _isAnalyzing ? Colors.blue : null,
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Emotion Camera Preview
            if (_cameraController != null &&
                _cameraController!.value.isInitialized)
              Container(
                height: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.blue, width: 2),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: CameraPreview(_cameraController!),
                ),
              ),

            const SizedBox(height: 20),

            // AI Recommendation
            if (_currentRecommendation != null) _buildRecommendationCard(),

            const SizedBox(height: 20),

            // Emotion History
            _buildEmotionHistory(),

            const SizedBox(height: 20),

            // AI Response
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'AI Coach',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.blue,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: _aiResponse.isEmpty
                          ? const Center(
                              child: Text(
                                'Tell me how you\'re feeling today...',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                            )
                          : SingleChildScrollView(
                              child: Text(
                                _aiResponse,
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _startListening,
        backgroundColor: _isListening ? Colors.red : Colors.blue,
        child: Icon(
          _isListening ? Icons.mic_off : Icons.mic,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _buildRecommendationCard() {
    final rec = _currentRecommendation!;

    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.purple.shade100, Colors.blue.shade100],
        ),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.auto_awesome, color: Colors.purple),
              const SizedBox(width: 10),
              const Text(
                'Personalized Recommendation',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
              const Spacer(),
              Text(
                '${(rec.confidence * 100).toInt()}% match',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            _getMeditationTypeName(rec.type),
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: Colors.purple,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            '${rec.duration.inMinutes} minutes',
            style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
          ),
          const SizedBox(height: 10),
          Text(rec.reason, style: const TextStyle(fontSize: 14)),
          const SizedBox(height: 15),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                // Start the recommended meditation
                _startMeditation(rec.type, rec.duration);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text(
                'START THIS MEDITATION',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmotionHistory() {
    if (_emotionHistory.isEmpty) return const SizedBox();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Recent Emotions',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 60,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _emotionHistory.length,
            itemBuilder: (context, index) {
              final data = _emotionHistory[index];
              return Container(
                margin: const EdgeInsets.only(right: 10),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _getEmotionColor(data.emotion.type),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      _getEmojiForEmotion(data.emotion.type),
                      style: const TextStyle(fontSize: 20),
                    ),
                    Text(
                      '${(data.confidence * 100).toInt()}%',
                      style: const TextStyle(fontSize: 10, color: Colors.white),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Color _getEmotionColor(EmotionType type) {
    switch (type) {
      case EmotionType.happy:
        return Colors.yellow;
      case EmotionType.sad:
        return Colors.blue;
      case EmotionType.angry:
        return Colors.red;
      case EmotionType.stressed:
        return Colors.orange;
      case EmotionType.tired:
        return Colors.grey;
      case EmotionType.neutral:
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _getEmojiForEmotion(EmotionType type) {
    switch (type) {
      case EmotionType.happy:
        return '😊';
      case EmotionType.sad:
        return '😢';
      case EmotionType.angry:
        return '😠';
      case EmotionType.stressed:
        return '😰';
      case EmotionType.tired:
        return '😴';
      case EmotionType.neutral:
        return '😐';
      default:
        return '🤔';
    }
  }

  String _getMeditationTypeName(MeditationType type) {
    switch (type) {
      case MeditationType.breathAwareness:
        return 'Breath Awareness';
      case MeditationType.bodyScan:
        return 'Body Scan';
      case MeditationType.lovingKindness:
        return 'Loving-Kindness';
      case MeditationType.gratitude:
        return 'Gratitude Practice';
      case MeditationType.stressRelief:
        return 'Stress Relief';
      case MeditationType.sleep:
        return 'Sleep Meditation';
      case MeditationType.energyBoost:
        return 'Energy Boost';
      default:
        return 'Mindfulness Meditation';
    }
  }

  void _startMeditation(MeditationType type, Duration duration) {
    // Navigate to meditation screen with selected type
    // This would be implemented based on your navigation structure
  }
}
