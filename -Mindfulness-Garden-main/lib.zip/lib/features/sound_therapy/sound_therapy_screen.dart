import 'package:flutter/material.dart';
import 'package:mindfulness_garden/core/services/audio_service.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'dart:math';

class SoundTherapyScreen extends StatefulWidget {
  const SoundTherapyScreen({super.key});

  @override
  State<SoundTherapyScreen> createState() => _SoundTherapyScreenState();
}

class _SoundTherapyScreenState extends State<SoundTherapyScreen>
    with SingleTickerProviderStateMixin {
  final AudioService _audioService = AudioService();
  late AnimationController _controller;
  late Animation<double> _animation;

  String? _selectedSound;
  double _volume = 0.7;
  bool _isPlaying = false;
  List<Map<String, dynamic>> _sounds = [];

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);

    _animation = Tween<double>(
      begin: 0.95,
      end: 1.05,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _loadSounds();
  }

  void _loadSounds() {
    _sounds = [
      {
        'id': 'ocean',
        'name': 'Ocean Waves',
        'description': 'Calming ocean sounds for relaxation',
        'icon': Icons.waves,
        'color': Colors.blue,
        'duration': '∞',
      },
      {
        'id': 'rain',
        'name': 'Gentle Rain',
        'description': 'Soft rain sounds for focus',
        'icon': Icons.grain,
        'color': Colors.blueAccent,
        'duration': '∞',
      },
      {
        'id': 'forest',
        'name': 'Forest Birds',
        'description': 'Peaceful forest ambiance',
        'icon': Icons.forest,
        'color': Colors.green,
        'duration': '∞',
      },
      {
        'id': 'bowl',
        'name': 'Singing Bowl',
        'description': 'Meditation bowl frequencies',
        'icon': Icons.trip_origin,
        'color': Colors.orange,
        'duration': '∞',
      },
      {
        'id': 'white',
        'name': 'White Noise',
        'description': 'Block distractions',
        'icon': Icons.graphic_eq,
        'color': Colors.grey,
        'duration': '∞',
      },
      {
        'id': 'piano',
        'name': 'Calm Piano',
        'description': 'Soothing piano melodies',
        'icon': Icons.piano,
        'color': Colors.purple,
        'duration': '∞',
      },
    ];
  }

  void _toggleSound(String soundId) async {
    if (_selectedSound == soundId && _isPlaying) {
      await _audioService.stopSound();
      setState(() {
        _isPlaying = false;
      });
    } else {
      await _audioService.playSound(soundId);
      setState(() {
        _selectedSound = soundId;
        _isPlaying = true;
      });
    }
  }

  void _setVolume(double volume) async {
    setState(() {
      _volume = volume;
    });
    await _audioService.setVolume(volume);
  }

  @override
  void dispose() {
    _controller.dispose();
    _audioService.stopSound();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sound Therapy'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1a1a2e), Color(0xFF16213e), Color(0xFF0f3460)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // Now Playing Card
                if (_selectedSound != null && _isPlaying)
                  AnimatedBuilder(
                    animation: _animation,
                    builder: (context, child) {
                      final sound = _sounds.firstWhere(
                        (s) => s['id'] == _selectedSound,
                        orElse: () => {},
                      );

                      return Transform.scale(
                        scale: _animation.value,
                        child: Container(
                          padding: const EdgeInsets.all(20),
                          margin: const EdgeInsets.only(bottom: 20),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                sound['color'].withOpacity(0.3),
                                sound['color'].withOpacity(0.1),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(25),
                            border: Border.all(
                              color: sound['color'].withOpacity(0.5),
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 60,
                                height: 60,
                                decoration: BoxDecoration(
                                  color: sound['color'].withOpacity(0.3),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  sound['icon'],
                                  size: 30,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(width: 20),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'NOW PLAYING',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.white.withOpacity(0.7),
                                        letterSpacing: 2,
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    Text(
                                      sound['name'],
                                      style: const TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white,
                                      ),
                                    ),
                                    Text(
                                      sound['description'],
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.white.withOpacity(0.8),
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                              IconButton(
                                onPressed: () => _toggleSound(_selectedSound!),
                                icon: Icon(
                                  Icons.stop,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),

                // Volume Control
                Container(
                  padding: const EdgeInsets.all(20),
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Volume',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Icon(Icons.volume_down, color: Colors.white),
                          Expanded(
                            child: Slider(
                              value: _volume,
                              onChanged: _setVolume,
                              min: 0.0,
                              max: 1.0,
                              divisions: 10,
                              activeColor: Colors.white,
                              inactiveColor: Colors.white.withOpacity(0.3),
                            ),
                          ),
                          const Icon(Icons.volume_up, color: Colors.white),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '${(_volume * 100).toInt()}%',
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            _isPlaying ? 'Playing' : 'Paused',
                            style: TextStyle(
                              fontSize: 14,
                              color: _isPlaying ? Colors.green : Colors.yellow,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Sounds Grid
                Expanded(
                  child: GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 15,
                          mainAxisSpacing: 15,
                          childAspectRatio: 1.2,
                        ),
                    itemCount: _sounds.length,
                    itemBuilder: (context, index) {
                      final sound = _sounds[index];
                      final isPlaying =
                          _selectedSound == sound['id'] && _isPlaying;

                      return GestureDetector(
                        onTap: () => _toggleSound(sound['id']),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: isPlaying
                                  ? [
                                      sound['color'],
                                      sound['color'].withOpacity(0.7),
                                    ]
                                  : [
                                      Colors.white.withOpacity(0.1),
                                      Colors.white.withOpacity(0.05),
                                    ],
                            ),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isPlaying
                                  ? sound['color'].withOpacity(0.5)
                                  : Colors.white.withOpacity(0.2),
                              width: isPlaying ? 2 : 1,
                            ),
                            boxShadow: isPlaying
                                ? [
                                    BoxShadow(
                                      color: sound['color'].withOpacity(0.3),
                                      blurRadius: 20,
                                      spreadRadius: 2,
                                    ),
                                  ]
                                : [],
                          ),
                          child: Stack(
                            children: [
                              // Background pattern
                              Positioned.fill(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: CustomPaint(
                                    painter: SoundWavePainter(
                                      animationValue: _controller.value,
                                      isPlaying: isPlaying,
                                      color: sound['color'],
                                    ),
                                  ),
                                ),
                              ),

                              // Content
                              Padding(
                                padding: const EdgeInsets.all(15),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 50,
                                      height: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.2),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        sound['icon'],
                                        size: 25,
                                        color: Colors.white,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Text(
                                      sound['name'],
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white,
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    Text(
                                      sound['duration'],
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.white.withOpacity(0.7),
                                      ),
                                    ),
                                    const Spacer(),
                                    if (isPlaying)
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.graphic_eq,
                                            size: 20,
                                            color: Colors.white,
                                          ),
                                          const SizedBox(width: 5),
                                          Expanded(
                                            child: LinearProgressIndicator(
                                              value: _controller.value,
                                              backgroundColor: Colors.white
                                                  .withOpacity(0.2),
                                              valueColor:
                                                  AlwaysStoppedAnimation(
                                                    Colors.white.withOpacity(
                                                      0.8,
                                                    ),
                                                  ),
                                            ),
                                          ),
                                        ],
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SoundWavePainter extends CustomPainter {
  final double animationValue;
  final bool isPlaying;
  final Color color;

  SoundWavePainter({
    required this.animationValue,
    required this.isPlaying,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (!isPlaying) return;

    final paint = Paint()
      ..color = color.withOpacity(0.1)
      ..style = PaintingStyle.fill;

    final waveCount = 5;
    final waveSpacing = size.width / (waveCount * 2);

    for (int i = 0; i < waveCount; i++) {
      final x = waveSpacing * (i * 2 + 1);
      final amplitude = size.height * 0.3;
      final frequency = 2.0;
      final offset = animationValue * 2 * 3.14159;

      final wavePath = Path();
      wavePath.moveTo(0, size.height / 2);

      for (double t = 0; t <= size.width; t += 1) {
        final y =
            size.height / 2 +
            sin(t * 0.05 * frequency + offset + i) *
                amplitude *
                (1 - (x - t).abs() / (size.width / 2));
        wavePath.lineTo(t, y);
      }

      wavePath.lineTo(size.width, size.height);
      wavePath.lineTo(0, size.height);
      wavePath.close();

      canvas.drawPath(wavePath, paint);
    }
  }

  @override
  bool shouldRepaint(covariant SoundWavePainter oldDelegate) {
    return animationValue != oldDelegate.animationValue ||
        isPlaying != oldDelegate.isPlaying ||
        color != oldDelegate.color;
  }
}
