import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mindfulness_garden/core/themes/app_theme.dart';
import 'package:mindfulness_garden/data/local_storage/local_storage_service.dart';
import 'package:mindfulness_garden/presentation/providers/app_provider.dart';
import 'package:mindfulness_garden/presentation/providers/user_provider.dart';
import 'package:mindfulness_garden/presentation/routes/app_router.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyB4kD7Uv4mzXq4z4q4q4q4q4q4q4q4q4q4q4q",
      authDomain: "mindfulness-garden.firebaseapp.com",
      projectId: "mindfulness-garden",
      storageBucket: "mindfulness-garden.appspot.com",
      messagingSenderId: "1234567890",
      appId: "1:1234567890:web:abcd1234efgh5678",
    ),
  );

  // Initialize local storage
  await LocalStorageService.init();

  runApp(const MindfulnessGardenApp());
}

class MindfulnessGardenApp extends StatefulWidget {
  const MindfulnessGardenApp({super.key});

  @override
  State<MindfulnessGardenApp> createState() => _MindfulnessGardenAppState();
}

class _MindfulnessGardenAppState extends State<MindfulnessGardenApp>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Handle app lifecycle changes if needed
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
      ],
      child: Builder(
        builder: (context) {
          final themeMode = context.select<AppProvider, ThemeMode>(
            (provider) => provider.themeMode,
          );

          return MaterialApp.router(
            debugShowCheckedModeBanner: false,
            title: 'Mindfulness Garden',
            theme: AppTheme.lightTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: themeMode,
            routerConfig: AppRouter.router,
            builder: (context, child) {
              return MediaQuery(
                data: MediaQuery.of(context).copyWith(
                  textScaler: TextScaler.noScaling,
                ),
                child: child!,
              );
            },
          );
        },
      ),
    );
  }
}
