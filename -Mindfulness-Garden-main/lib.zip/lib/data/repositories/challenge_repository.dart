import 'package:mindfulness_garden/data/models/challenge_model.dart';
import 'package:mindfulness_garden/data/local_storage/local_storage_service.dart';

class ChallengeRepository {
  Future<List<Challenge>> getChallenges() async {
    // Mock data - in production, this would come from an API
    return [
      Challenge(
        id: '1',
        title: 'Morning Meditation',
        description: 'Meditate for 5 minutes in the morning',
        type: ChallengeType.daily,
        reward: 50,
        isCompleted: false,
        progress: 0.0,
      ),
      Challenge(
        id: '2',
        title: 'Week Streak',
        description: 'Complete 7 days of meditation',
        type: ChallengeType.weekly,
        reward: 200,
        isCompleted: false,
        progress: 3 / 7,
      ),
      Challenge(
        id: '3',
        title: 'Breath Master',
        description: 'Complete 3 different breathing exercises',
        type: ChallengeType.achievement,
        reward: 100,
        isCompleted: false,
        progress: 1 / 3,
      ),
      Challenge(
        id: '4',
        title: 'Garden Growth',
        description: 'Grow 5 plants in your garden',
        type: ChallengeType.garden,
        reward: 150,
        isCompleted: false,
        progress: 2 / 5,
      ),
    ];
  }

  Future<Challenge?> getTodayChallenge() async {
    final challenges = await getChallenges();
    return challenges.firstWhere(
      (challenge) => challenge.type == ChallengeType.daily,
      orElse: () => Challenge(
        id: 'default',
        title: 'Daily Meditation',
        description: 'Complete any meditation session',
        type: ChallengeType.daily,
        reward: 25,
        isCompleted: false,
        progress: 0.0,
      ),
    );
  }

  Future<Map<String, bool>> getCompletedChallenges() async {
    return {};
  }

  Future<int> getPoints() async {
    return 0;
  }

  Future<void> completeChallenge(String challengeId) async {
    // Save to local storage
    await LocalStorageService.saveSetting('challenge_$challengeId', true);
  }

  Future<void> claimReward(String challengeId) async {
    // Mark reward as claimed
    await LocalStorageService.saveSetting('reward_$challengeId', true);
  }
}
